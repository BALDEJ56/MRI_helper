import os, secrets
from flask import Flask, send_from_directory
from werkzeug.security import generate_password_hash
import sqlite3, time


def create_app(data_dir=None, test_config=None):
    app = Flask(__name__, static_folder="static", static_url_path="")
    data_dir = data_dir or os.environ.get("SPONDY_DATA", os.path.join(os.path.dirname(os.path.dirname(__file__)), "data"))
    os.makedirs(data_dir, exist_ok=True)
    key_file = os.path.join(data_dir, ".secret_key")
    if not os.path.exists(key_file):
        with open(key_file, "w") as f:
            f.write(secrets.token_hex(32))
        os.chmod(key_file, 0o600)
    app.config.update(SECRET_KEY=open(key_file).read(), DB_PATH=os.path.join(data_dir, "spondy.db"),
                      VOL_DIR=os.path.join(data_dir, "volumes"), ANN_DIR=os.path.join(data_dir, "annotations"),
                      MAX_CONTENT_LENGTH=800 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    if test_config:
        app.config.update(test_config)
    from .db import init_db
    init_db(app)
    from .api import bp
    app.register_blueprint(bp)
    _bootstrap_admin(app)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.after_request
    def sec(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        return resp
    return app


def _bootstrap_admin(app):
    con = sqlite3.connect(app.config["DB_PATH"])
    if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        pw = os.environ.get("SPONDY_ADMIN_PASSWORD") or secrets.token_urlsafe(9)
        con.execute("INSERT INTO users(username,pw_hash,role,created) VALUES('admin',?,?,?)", (generate_password_hash(pw), "admin", time.time()))
        con.commit()
        if not os.environ.get("SPONDY_ADMIN_PASSWORD"):
            print(f"\n=== Создан пользователь admin, пароль: {pw}  (смените/сохраните его; показывается один раз) ===\n")
    con.close()
