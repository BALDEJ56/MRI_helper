"""REST API: авторизация, реестр пациентов, загрузка DICOM, анализ, вердикты врача, разметка, статистика, экспорт."""
import os, io, json, time, base64, tempfile, shutil, csv, functools
import numpy as np, cv2
from PIL import Image
from flask import Blueprint, request, jsonify, session, send_file, current_app, abort, Response
from werkzeug.security import generate_password_hash, check_password_hash
from .db import get_db, rows, audit
from .core.config import AnalysisParams
from .core.dicom_io import load_series_from_paths
from .core.pipeline import analyze_series
from .core.preprocess import window_to_uint8, robust_scale
from .core import metrics as M
from . import storage, exporter

bp = Blueprint("api", __name__, url_prefix="/api")
TARGET_PATIENTS, TARGET_SLICES = 40, 15   # план по базе: сейчас 15 пациентов, далее 40×15 снимков


# ---------- служебное ----------
def err(msg, code=400):
    return jsonify({"error": msg}), code


def me():
    return session.get("user")


def login_required(role=None):
    def deco(f):
        @functools.wraps(f)
        def w(*a, **k):
            if not me():
                return err("Требуется вход", 401)
            if request.method in ("POST", "PUT", "DELETE") and request.headers.get("X-Requested-With") != "fetch":
                return err("CSRF", 403)
            if role and session.get("role") != role:
                return err("Недостаточно прав", 403)
            return f(*a, **k)
        return w
    return deco


@bp.before_request
def _csrf_login():
    if request.endpoint == "api.login" and request.headers.get("X-Requested-With") != "fetch":
        return err("CSRF", 403)


def vol_of(series_row):
    return storage.load_volume(current_app.config["VOL_DIR"], series_row["vol_file"])


def default_params() -> AnalysisParams:
    r = get_db().execute("SELECT value FROM settings WHERE key='params'").fetchone()
    return AnalysisParams.from_dict(json.loads(r["value"])) if r else AnalysisParams()


# ---------- авторизация ----------
@bp.post("/login")
def login():
    d = request.get_json(force=True, silent=True) or {}
    u = get_db().execute("SELECT * FROM users WHERE username=?", (d.get("username", ""),)).fetchone()
    if not u or not check_password_hash(u["pw_hash"], d.get("password", "")):
        audit(d.get("username", "?"), "login_failed")
        return err("Неверный логин или пароль", 401)
    session.clear(); session["user"] = u["username"]; session["role"] = u["role"]
    audit(u["username"], "login")
    return jsonify({"user": u["username"], "role": u["role"]})


@bp.post("/logout")
@login_required()
def logout():
    audit(me(), "logout"); session.clear()
    return jsonify({"ok": True})


@bp.get("/me")
def whoami():
    return jsonify({"user": me(), "role": session.get("role")}) if me() else err("Не выполнен вход", 401)


@bp.post("/users")
@login_required("admin")
def add_user():
    d = request.get_json(force=True)
    if not d.get("username") or len(d.get("password", "")) < 8:
        return err("Логин обязателен, пароль – не короче 8 символов")
    try:
        get_db().execute("INSERT INTO users(username,pw_hash,role,created) VALUES(?,?,?,?)",
                         (d["username"], generate_password_hash(d["password"]), d.get("role", "doctor"), time.time()))
        get_db().commit()
    except Exception:
        return err("Пользователь уже существует")
    audit(me(), "user_add", d["username"])
    return jsonify({"ok": True})


# ---------- настройки ----------
@bp.get("/settings/params")
@login_required()
def get_params():
    return jsonify(default_params().to_dict())


@bp.put("/settings/params")
@login_required("admin")
def put_params():
    p = AnalysisParams.from_dict(request.get_json(force=True))
    db = get_db()
    db.execute("INSERT INTO settings(key,value) VALUES('params',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
               (json.dumps(p.to_dict()),))
    db.commit(); audit(me(), "params_update")
    return jsonify(p.to_dict())


# ---------- пациенты (интерактивный регистр) ----------
PFIELDS = ["sex", "birth_year", "diagnosis", "axspa", "crp", "hla_b27", "basdai", "asdas", "therapy", "notes"]


def _pat_summary(db, where="", args=()):
    q = f"""SELECT p.*, (SELECT COUNT(*) FROM studies s WHERE s.patient_id=p.id) n_studies,
      (SELECT GROUP_CONCAT(DISTINCT s.device_key) FROM studies s WHERE s.patient_id=p.id) devices,
      (SELECT GROUP_CONCAT(DISTINCT s.region) FROM studies s WHERE s.patient_id=p.id) regions,
      (SELECT a.positive FROM analyses a JOIN studies s ON s.id=a.study_id WHERE s.patient_id=p.id AND a.mode='active'
         ORDER BY a.id DESC LIMIT 1) ai_positive,
      (SELECT v.positive FROM verdicts v JOIN analyses a ON a.id=v.analysis_id JOIN studies s ON s.id=a.study_id
         WHERE s.patient_id=p.id ORDER BY v.id DESC LIMIT 1) doctor_positive
      FROM patients p {where} ORDER BY p.id DESC"""
    return rows(db.execute(q, args))


@bp.get("/patients")
@login_required()
def patients():
    db = get_db(); qs = request.args.get("q", "").strip()
    out = _pat_summary(db, "WHERE p.code LIKE ? OR p.diagnosis LIKE ? OR p.notes LIKE ?", (f"%{qs}%",) * 3) if qs else _pat_summary(db)
    return jsonify(out)


@bp.post("/patients")
@login_required()
def patient_add():
    db = get_db(); d = request.get_json(force=True, silent=True) or {}
    n = (db.execute("SELECT COALESCE(MAX(id),0) m FROM patients").fetchone()["m"]) + 1
    code = (d.get("code") or f"P-{n:04d}").strip()
    try:
        cur = db.execute("INSERT INTO patients(code,created,created_by) VALUES(?,?,?)", (code, time.time(), me()))
    except Exception:
        return err("Код пациента уже существует")
    pid = cur.lastrowid
    _patient_update(db, pid, d); db.commit(); audit(me(), "patient_add", code)
    return jsonify({"id": pid, "code": code})


def _patient_update(db, pid, d):
    sets, vals = [], []
    for f in PFIELDS:
        if f in d:
            v = d[f]
            if v == "":
                v = None
            sets.append(f"{f}=?"); vals.append(v)
    if sets:
        db.execute(f"UPDATE patients SET {','.join(sets)} WHERE id=?", (*vals, pid))


@bp.get("/patients/<int:pid>")
@login_required()
def patient_get(pid):
    db = get_db()
    p = db.execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()
    if not p:
        return err("Не найден", 404)
    studies = rows(db.execute("SELECT * FROM studies WHERE patient_id=? ORDER BY id DESC", (pid,)))
    for s in studies:
        s["series"] = rows(db.execute("SELECT id,description,plane,weighting,n_slices FROM series WHERE study_id=?", (s["id"],)))
        a = db.execute("SELECT id,positive,mode,created FROM analyses WHERE study_id=? AND mode='active' ORDER BY id DESC LIMIT 1", (s["id"],)).fetchone()
        s["analysis"] = dict(a) if a else None
        v = db.execute("SELECT v.positive,v.doctor FROM verdicts v JOIN analyses a ON a.id=v.analysis_id WHERE a.study_id=? ORDER BY v.id DESC LIMIT 1", (s["id"],)).fetchone()
        s["verdict"] = dict(v) if v else None
    return jsonify({"patient": dict(p), "studies": studies})


@bp.put("/patients/<int:pid>")
@login_required()
def patient_put(pid):
    db = get_db(); _patient_update(db, pid, request.get_json(force=True)); db.commit()
    audit(me(), "patient_update", pid)
    return jsonify({"ok": True})


@bp.delete("/patients/<int:pid>")
@login_required("admin")
def patient_del(pid):
    db = get_db()
    for r in db.execute("SELECT s.vol_file FROM series s JOIN studies st ON st.id=s.study_id WHERE st.patient_id=?", (pid,)):
        try:
            os.remove(os.path.join(current_app.config["VOL_DIR"], r["vol_file"]))
        except OSError:
            pass
    db.execute("DELETE FROM patients WHERE id=?", (pid,)); db.commit(); audit(me(), "patient_delete", pid)
    return jsonify({"ok": True})


# ---------- загрузка DICOM ----------
@bp.post("/patients/<int:pid>/upload")
@login_required()
def upload(pid):
    db = get_db()
    if not db.execute("SELECT 1 FROM patients WHERE id=?", (pid,)).fetchone():
        return err("Пациент не найден", 404)
    files = request.files.getlist("files")
    if not files:
        return err("Файлы не выбраны")
    region_forced = request.form.get("region") or None
    tmp = tempfile.mkdtemp(prefix="spondy_")
    try:
        for i, f in enumerate(files):
            name = os.path.basename((f.filename or f"f{i}").replace("\\", "/")) or f"f{i}"
            f.save(os.path.join(tmp, f"{i:05d}_{name}"))
        series = load_series_from_paths([tmp])
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return err(f"Не удалось прочитать DICOM: {e}")
    shutil.rmtree(tmp, ignore_errors=True)
    if not series:
        return err("DICOM-серии (MR) не найдены в выбранных файлах")
    added, skipped = [], []
    study_ids = {}
    for s in series:
        if s.weighting == "LOCALIZER":
            skipped.append({"description": s.description, "reason": "локалайзер"}); continue
        if db.execute("SELECT 1 FROM series WHERE series_uid=?", (s.series_uid,)).fetchone():
            skipped.append({"description": s.description, "reason": "уже загружена"}); continue
        if s.study_uid not in study_ids:
            ex = db.execute("SELECT id FROM studies WHERE patient_id=? AND study_uid=?", (pid, s.study_uid)).fetchone()
            if ex:
                study_ids[s.study_uid] = ex["id"]
            else:
                d = s.study_date
                dt = f"{d[:4]}-{d[4:6]}-{d[6:8]}" if len(d) == 8 else d
                cur = db.execute("INSERT INTO studies(patient_id,region,study_date,device_key,study_uid,created) VALUES(?,?,?,?,?,?)",
                                 (pid, region_forced or s.region_guess, dt, s.device_key, s.study_uid, time.time()))
                study_ids[s.study_uid] = cur.lastrowid
        fname = storage.save_volume(current_app.config["VOL_DIR"], "v" + s.series_uid.replace(".", "")[-20:] + f"_{int(time.time()*1000)%100000}", s.volume)
        cur = db.execute("INSERT INTO series(study_id,series_uid,description,plane,weighting,n_slices,meta_json,vol_file) VALUES(?,?,?,?,?,?,?,?)",
                         (study_ids[s.study_uid], s.series_uid, s.description, s.plane, s.weighting, s.n_slices, json.dumps(s.meta()), fname))
        added.append({"series_id": cur.lastrowid, "description": s.description, "weighting": s.weighting, "plane": s.plane,
                      "device": s.device_key, "n_slices": s.n_slices})
        p = db.execute("SELECT sex,birth_year FROM patients WHERE id=?", (pid,)).fetchone()
        if not p["sex"] and s.patient_sex in ("M", "F"):
            db.execute("UPDATE patients SET sex=? WHERE id=?", (s.patient_sex, pid))
    db.commit(); audit(me(), "upload", f"patient={pid} series={len(added)}")
    return jsonify({"added": added, "skipped": skipped, "study_ids": list(study_ids.values())})


# ---------- исследования и серии ----------
@bp.get("/studies/<int:sid>")
@login_required()
def study_get(sid):
    db = get_db()
    s = db.execute("SELECT st.*, p.code patient_code FROM studies st JOIN patients p ON p.id=st.patient_id WHERE st.id=?", (sid,)).fetchone()
    if not s:
        return err("Не найдено", 404)
    ser = rows(db.execute("SELECT id,description,plane,weighting,n_slices,meta_json FROM series WHERE study_id=? ORDER BY id", (sid,)))
    for x in ser:
        x["meta"] = json.loads(x.pop("meta_json"))
        x["n_annotated"] = db.execute("SELECT COUNT(DISTINCT slice_index) c FROM annotations WHERE series_id=?", (x["id"],)).fetchone()["c"]
    an = rows(db.execute("SELECT id,series_id,mode,positive,version,created,created_by FROM analyses WHERE study_id=? ORDER BY id DESC", (sid,)))
    return jsonify({"study": dict(s), "series": ser, "analyses": an})


@bp.put("/studies/<int:sid>")
@login_required()
def study_put(sid):
    d = request.get_json(force=True); db = get_db()
    if "region" in d and d["region"] in ("lumbar", "sij"):
        db.execute("UPDATE studies SET region=? WHERE id=?", (d["region"], sid))
    if "note" in d:
        db.execute("UPDATE studies SET note=? WHERE id=?", (d["note"], sid))
    db.commit()
    return jsonify({"ok": True})


@bp.get("/series/<int:sid>/slice/<int:i>.png")
@login_required()
def slice_png(sid, i):
    r = get_db().execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
    if not r:
        abort(404)
    vol = vol_of(r)
    if not 0 <= i < len(vol):
        abort(404)
    lo = float(request.args.get("lo", np.percentile(vol, 1)))
    hi = float(request.args.get("hi", np.percentile(vol, 99.7)))
    if hi <= lo:
        hi = lo + 1
    img = (np.clip((vol[i] - lo) / (hi - lo), 0, 1) * 255).astype(np.uint8)
    ok, buf = cv2.imencode(".png", img)
    return Response(buf.tobytes(), mimetype="image/png", headers={"Cache-Control": "private, max-age=60"})


@bp.get("/series/<int:sid>/window")
@login_required()
def series_window(sid):
    r = get_db().execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
    if not r:
        return err("Не найдено", 404)
    vol = vol_of(r)
    return jsonify({"lo": float(np.percentile(vol, 1)), "hi": float(np.percentile(vol, 99.7)), "min": float(vol.min()),
                    "max": float(vol.max()), "shape": list(vol.shape)})


# ---------- анализ ----------
def _save_analysis(db, study_id, series_id, mode, params, res):
    cur = db.execute("INSERT INTO analyses(study_id,series_id,mode,params_json,result_json,positive,version,created,created_by) VALUES(?,?,?,?,?,?,?,?,?)",
                     (study_id, series_id, mode, json.dumps(params.to_dict()), json.dumps(res), int(res["study"]["positive"]),
                      res["version"], time.time(), me()))
    return cur.lastrowid


@bp.post("/studies/<int:sid>/analyze")
@login_required()
def analyze(sid):
    db = get_db(); d = request.get_json(force=True, silent=True) or {}
    st = db.execute("SELECT * FROM studies WHERE id=?", (sid,)).fetchone()
    if not st:
        return err("Не найдено", 404)
    if st["region"] == "sij":
        return err("Модуль крестцово-подвздошных суставов (КПС) в разработке: доступны просмотр, разметка и регистр. "
                   "Анализ пока реализован для поясничного отдела.", 501)
    sers = rows(db.execute("SELECT * FROM series WHERE study_id=? AND plane='sagittal'", (sid,)))
    pick = None
    if d.get("series_id"):
        pick = next((s for s in sers if s["id"] == int(d["series_id"])), None)
    pick = pick or next((s for s in sers if s["weighting"] == "STIR"), None) or next((s for s in sers if s["weighting"] == "T2"), None)
    if not pick:
        return err("В исследовании нет сагиттальной серии STIR/T2 – анализ невозможен")
    params = AnalysisParams.from_dict({**default_params().to_dict(), **(d.get("params") or {})})
    meta = json.loads(pick["meta_json"])
    t0 = time.time()
    res = analyze_series(vol_of(pick), meta["spacing_mm"], params, mode="active")
    res["series"] = {"id": pick["id"], "description": pick["description"], "device": meta["device_key"], "seconds": round(time.time() - t0, 2)}
    out = {"active": _save_analysis(db, sid, pick["id"], "active", params, res)}
    if d.get("with_t1", True):
        t1 = next((s for s in sers if s["weighting"] == "T1" and s["n_slices"] == pick["n_slices"]), None)
        if t1:
            m1 = json.loads(t1["meta_json"])
            if m1["rows"] == meta["rows"] and m1["cols"] == meta["cols"]:
                r1 = analyze_series(vol_of(t1), m1["spacing_mm"], params, mode="chronic", geometry_from=res)
                r1["series"] = {"id": t1["id"], "description": t1["description"], "device": m1["device_key"],
                                "note": "экспериментально; геометрия позвонков перенесена со STIR"}
                out["chronic"] = _save_analysis(db, sid, t1["id"], "chronic", params, r1)
    db.commit(); audit(me(), "analyze", f"study={sid} series={pick['id']} positive={res['study']['positive']}")
    return jsonify({"analysis_ids": out, "result": res})


@bp.get("/analyses/<int:aid>")
@login_required()
def analysis_get(aid):
    db = get_db()
    a = db.execute("SELECT * FROM analyses WHERE id=?", (aid,)).fetchone()
    if not a:
        return err("Не найдено", 404)
    v = db.execute("SELECT * FROM verdicts WHERE analysis_id=? ORDER BY id DESC LIMIT 1", (aid,)).fetchone()
    verdict = None
    if v:
        verdict = dict(v); verdict["slice_labels"] = json.loads(verdict.pop("slice_labels_json") or "{}")
    return jsonify({"id": aid, "mode": a["mode"], "series_id": a["series_id"], "study_id": a["study_id"], "created": a["created"],
                    "result": json.loads(a["result_json"]), "verdict": verdict})


@bp.post("/analyses/<int:aid>/verdict")
@login_required()
def verdict(aid):
    d = request.get_json(force=True); db = get_db()
    if not db.execute("SELECT 1 FROM analyses WHERE id=?", (aid,)).fetchone():
        return err("Не найдено", 404)
    labels = {str(k): int(bool(v)) for k, v in (d.get("slice_labels") or {}).items()}
    db.execute("INSERT INTO verdicts(analysis_id,doctor,positive,slice_labels_json,comment,created) VALUES(?,?,?,?,?,?)",
               (aid, me(), None if d.get("positive") is None else int(bool(d["positive"])), json.dumps(labels), d.get("comment", ""), time.time()))
    db.commit(); audit(me(), "verdict", f"analysis={aid}")
    return jsonify({"ok": True})


# ---------- разметка (для обучающей выборки) ----------
CLASSES = list(exporter.CLASSES)


def _ann_dir():
    return current_app.config["ANN_DIR"]


@bp.get("/series/<int:sid>/annotations")
@login_required()
def ann_list(sid):
    r = rows(get_db().execute("SELECT slice_index,GROUP_CONCAT(cls) classes FROM annotations WHERE series_id=? GROUP BY slice_index", (sid,)))
    return jsonify({r_["slice_index"]: r_["classes"].split(",") for r_ in r})


@bp.get("/series/<int:sid>/annotations/<int:i>/<cls>.png")
@login_required()
def ann_png(sid, i, cls):
    a = get_db().execute("SELECT file FROM annotations WHERE series_id=? AND slice_index=? AND cls=?", (sid, i, cls)).fetchone()
    if not a:
        abort(404)
    return send_file(os.path.join(_ann_dir(), a["file"]), mimetype="image/png")


def _decode_mask(data_url, shape):
    raw = base64.b64decode(data_url.split(",", 1)[1])
    im = Image.open(io.BytesIO(raw)).convert("RGBA")
    a = np.array(im)
    m = (a[..., 3] > 127) if a[..., 3].min() < 255 else (a[..., :3].max(-1) > 127)
    if m.shape != shape:
        m = cv2.resize(m.astype(np.uint8), (shape[1], shape[0]), interpolation=cv2.INTER_NEAREST).astype(bool)
    return m


@bp.put("/series/<int:sid>/annotations/<int:i>")
@login_required()
def ann_put(sid, i):
    db = get_db(); r = db.execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
    if not r:
        return err("Не найдено", 404)
    shape = json.loads(r["meta_json"]); shape = (shape["rows"], shape["cols"])
    os.makedirs(_ann_dir(), exist_ok=True)
    masks = (request.get_json(force=True) or {}).get("masks", {})
    for cls in CLASSES:
        if cls not in masks:
            continue
        old = db.execute("SELECT file FROM annotations WHERE series_id=? AND slice_index=? AND cls=?", (sid, i, cls)).fetchone()
        m = _decode_mask(masks[cls], shape) if masks[cls] else None
        if m is None or not m.any():
            if old:
                try: os.remove(os.path.join(_ann_dir(), old["file"]))
                except OSError: pass
                db.execute("DELETE FROM annotations WHERE series_id=? AND slice_index=? AND cls=?", (sid, i, cls))
            continue
        fname = f"s{sid}_{i:02d}_{cls}.png"
        cv2.imwrite(os.path.join(_ann_dir(), fname), (m.astype(np.uint8) * 255))
        db.execute("""INSERT INTO annotations(series_id,slice_index,cls,file,author,updated) VALUES(?,?,?,?,?,?)
            ON CONFLICT(series_id,slice_index,cls) DO UPDATE SET file=excluded.file,author=excluded.author,updated=excluded.updated""",
                   (sid, i, cls, fname, me(), time.time()))
    db.commit(); audit(me(), "annotate", f"series={sid} slice={i}")
    return jsonify({"ok": True})


@bp.post("/series/<int:sid>/annotations/<int:i>/prefill")
@login_required()
def ann_prefill(sid, i):
    """Предразметка по результату алгоритма (врач правит, а не рисует с нуля)."""
    db = get_db(); d = request.get_json(force=True)
    a = db.execute("SELECT result_json FROM analyses WHERE id=? AND series_id=?", (d.get("analysis_id"), sid)).fetchone()
    r = db.execute("SELECT meta_json FROM series WHERE id=?", (sid,)).fetchone()
    if not a or not r:
        return err("Нет результата анализа для этой серии", 404)
    meta = json.loads(r["meta_json"]); H, W = meta["rows"], meta["cols"]
    sl = json.loads(a["result_json"])["slices"][i]
    out = {c: np.zeros((H, W), np.uint8) for c in CLASSES}
    for v in sl["vertebrae"]:
        if not v.get("extrapolated"):
            cv2.fillPoly(out["body"], [np.round(np.array(v["quad"])).astype(np.int32)], 255)
        for c in v["corners"].values():
            if c["positive"] and c["contour"]:
                cv2.fillPoly(out["lesion"], [np.round(np.array(c["contour"])).astype(np.int32)], 255)
    for dsc in sl.get("discs", []):
        cv2.fillPoly(out["disc"], [np.round(np.array(dsc)).astype(np.int32)], 255)
    res = {}
    for c, m in out.items():
        rgba = np.zeros((H, W, 4), np.uint8); rgba[..., 0:3] = 255; rgba[..., 3] = m
        buf = io.BytesIO(); Image.fromarray(rgba).save(buf, "PNG")
        res[c] = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    return jsonify({"masks": res})


# ---------- статистика / экспорт ----------
def _latest_verdicts(db, mode="active"):
    return rows(db.execute("""SELECT a.id aid, a.result_json, a.positive ai_pos, v.positive doc_pos, v.slice_labels_json, st.device_key, st.region
        FROM analyses a JOIN studies st ON st.id=a.study_id
        JOIN verdicts v ON v.id=(SELECT MAX(id) FROM verdicts WHERE analysis_id=a.id)
        WHERE a.mode=? AND a.id=(SELECT MAX(id) FROM analyses WHERE study_id=a.study_id AND mode=?)""", (mode, mode)))


@bp.get("/stats")
@login_required()
def stats():
    db = get_db()
    one = lambda q: db.execute(q).fetchone()[0]
    out = {"patients": one("SELECT COUNT(*) FROM patients"), "studies": one("SELECT COUNT(*) FROM studies"),
           "series": one("SELECT COUNT(*) FROM series"), "analyses": one("SELECT COUNT(*) FROM analyses"),
           "verdicts": one("SELECT COUNT(*) FROM verdicts"),
           "by_device": rows(db.execute("SELECT COALESCE(device_key,'?') device, COUNT(*) n FROM studies GROUP BY device_key")),
           "by_region": rows(db.execute("SELECT region, COUNT(*) n FROM studies GROUP BY region")),
           "targets": {"patients": TARGET_PATIENTS, "slices_per_patient": TARGET_SLICES, "quality": M.TARGETS}}
    out["annotated_slices"] = one("SELECT COUNT(*) FROM (SELECT DISTINCT series_id, slice_index FROM annotations)")
    out["annotated_patients"] = one("""SELECT COUNT(DISTINCT st.patient_id) FROM annotations an JOIN series s ON s.id=an.series_id JOIN studies st ON st.id=s.study_id""")
    out["ai_positive_studies"] = one("SELECT COUNT(*) FROM analyses a WHERE mode='active' AND positive=1 AND id=(SELECT MAX(id) FROM analyses WHERE study_id=a.study_id AND mode='active')")
    out["ai_negative_studies"] = one("SELECT COUNT(*) FROM analyses a WHERE mode='active' AND positive=0 AND id=(SELECT MAX(id) FROM analyses WHERE study_id=a.study_id AND mode='active')")
    vs = [v for v in _latest_verdicts(db) if v["doc_pos"] is not None]
    out["agreement_study"] = M.classification_metrics([v["doc_pos"] for v in vs], [v["ai_pos"] for v in vs]) if vs else None
    by_dev = {}
    for v in vs:
        by_dev.setdefault(v["device_key"] or "?", []).append(v)
    out["agreement_by_device"] = {k: M.classification_metrics([x["doc_pos"] for x in l], [x["ai_pos"] for x in l]) for k, l in by_dev.items()}
    yt, yp = [], []
    for v in _latest_verdicts(db):
        lab = json.loads(v["slice_labels_json"] or "{}"); sl = json.loads(v["result_json"])["slices"]
        for k, val in lab.items():
            k = int(k)
            if k < len(sl) and sl[k]["informative"]:
                yt.append(val); yp.append(int(sl[k]["positive"]))
    out["agreement_slices"] = M.classification_metrics(yt, yp) if yt else None
    # согласие между читателями (разные врачи/студенты по одному исследованию) – [4.docx: оценка эффективности двумя группами]
    byan = {}
    for r_ in rows(db.execute("SELECT analysis_id, doctor, positive FROM verdicts WHERE positive IS NOT NULL AND id IN (SELECT MAX(id) FROM verdicts GROUP BY analysis_id, doctor)")):
        byan.setdefault(r_["analysis_id"], {})[r_["doctor"]] = r_["positive"]
    pa, pb = [], []
    for v in byan.values():
        if len(v) >= 2:
            k = sorted(v)[:2]; pa.append(v[k[0]]); pb.append(v[k[1]])
    out["reader_agreement"] = M.classification_metrics(pa, pb) if pa else None
    return jsonify(out)


@bp.get("/export/registry.csv")
@login_required()
def export_csv():
    db = get_db(); buf = io.StringIO(); w = csv.writer(buf, delimiter=";")
    w.writerow(["code", "sex", "birth_year", "diagnosis", "axspa", "crp", "hla_b27", "basdai", "asdas", "therapy", "n_studies", "devices", "regions", "ai_positive", "doctor_positive"])
    for p in _pat_summary(db):
        w.writerow([p[k] for k in ("code", "sex", "birth_year", "diagnosis", "axspa", "crp", "hla_b27", "basdai", "asdas", "therapy", "n_studies", "devices", "regions", "ai_positive", "doctor_positive")])
    audit(me(), "export_registry")
    return Response("\ufeff" + buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=registry.csv"})


@bp.get("/export/dataset.zip")
@login_required()
def export_dataset():
    db = get_db(); vd = current_app.config["VOL_DIR"]
    buf, n = exporter.build_dataset_zip(db, _ann_dir(), lambda f: storage.load_volume(vd, f))
    audit(me(), "export_dataset", n)
    return send_file(buf, mimetype="application/zip", as_attachment=True, download_name="dataset.zip")


@bp.get("/audit")
@login_required("admin")
def audit_log():
    return jsonify(rows(get_db().execute("SELECT * FROM audit ORDER BY id DESC LIMIT 300")))
