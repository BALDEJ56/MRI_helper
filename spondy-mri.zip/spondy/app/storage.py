"""Хранилище объёмов (npz) – только пиксели и обезличенные метаданные, без ФИО/ID пациента (ФЗ-152)."""
import os, functools, numpy as np


def save_volume(folder, name, vol: np.ndarray):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name + ".npz")
    if np.allclose(vol, np.round(vol)) and vol.min() >= 0 and vol.max() < 65535:
        np.savez_compressed(path, v=vol.astype(np.uint16))
    else:
        np.savez_compressed(path, v=vol.astype(np.float32))
    return name + ".npz"


@functools.lru_cache(maxsize=6)
def _load(path):
    return np.load(path)["v"].astype(np.float32)


def load_volume(folder, fname):
    return _load(os.path.join(folder, fname))
