"""Текст заключения («окно» с рекомендацией – [2.docx 00:15:04]: «есть признаки активного воспаления»)."""
from .lesions import CORNER_RU

DISCLAIMER = ("Результат носит вспомогательный характер (поддержка принятия решения) и не является диагнозом; "
              "требуется оценка врача-рентгенолога/ревматолога.")


def make_conclusion(positive, findings, informative, P, mode="active"):
    if not informative:
        return "Информативные срезы не найдены: анализ невозможен. Проверьте серию (сагиттальный STIR, поясничный отдел). " + DISCLAIMER
    if mode == "chronic":
        head = "Экспериментальный Т1-анализ: " + ("выявлены гиперинтенсивные (жировые) угловые зоны, возможны хронические изменения."
                                                    if positive else "гиперинтенсивных угловых зон не выявлено.")
    else:
        head = ("Есть признаки активного воспаления (гиперинтенсивный сигнал в углах позвонков на STIR)."
                if positive else "Признаков активного воспаления в углах позвонков не выявлено.")
    lines = [head]
    if findings:
        by = {}
        for f in findings:
            by.setdefault(f["level"], []).append(f"{CORNER_RU[f['corner']]} угол (срезы {', '.join(str(i + 1) for i in f['slices'])})")
        lines.append("Позвонки: " + "; ".join(f"{lv}: {', '.join(v)}" for lv, v in by.items()) + ".")
    n = max(P.min_consecutive_slices, 2) if mode == "chronic" else P.min_consecutive_slices
    lines.append(f"Правило: очаг учитывается при наличии минимум на {n} последовательн. срез(ах). "
                 f"Информативных срезов: {len(informative)}.")
    lines.append(DISCLAIMER)
    return " ".join(lines)
