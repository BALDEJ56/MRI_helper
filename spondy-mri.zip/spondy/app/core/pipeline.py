"""Сквозной конвейер анализа серии: нормализация → диски → позвонки → угловые зоны → правило по срезам."""
from __future__ import annotations
from typing import Optional
import numpy as np
from .config import AnalysisParams
from .preprocess import normalize_volume, smooth
from .spine_geometry import find_discs, build_vertebrae
from .lesions import analyze_vertebra, CORNERS, CORNER_RU

VERSION = "0.1-baseline"
T1_REL_GAIN = 1.4       # экспериментально: жировые углы в Т1 ярче окружающего костного мозга [тема ВКР: структурные (хронические) изменения в Т1]


def _center_y(v):
    return float(v.quad[:, 1].mean())


def _assign_labels(slice_vs, levels, usable):
    """Подписи уровней: стек нумеруется снизу вверх (нижний = S1, т.к. ниже диска L5–S1).
    Опорный срез – из срезов с наиболее частым числом позвонков (устойчиво к выбросам);
    остальные срезы сопоставляются с ним по вертикальной координате."""
    from collections import Counter
    cand = [i for i in range(len(slice_vs)) if usable[i]]
    if not cand:
        return [[None] * len(vs) for vs in slice_vs]
    mode = Counter(len(slice_vs[i]) for i in cand).most_common(1)[0][0]
    ref_i = next(i for i in cand if len(slice_vs[i]) == mode)
    ref = slice_vs[ref_i]
    k = len(ref)
    ref_lab = {j: (levels[len(levels) - (k - j)] if 0 <= len(levels) - (k - j) < len(levels) else None) for j in range(k)}
    ref_y = [_center_y(v) for v in ref]
    tol = 0.6 * float(np.median([np.linalg.norm(v.quad[3] - v.quad[0]) for v in ref]))
    out = []
    for vs in slice_vs:
        labs = []
        for v in vs:
            d = [abs(_center_y(v) - ry) for ry in ref_y]
            j = int(np.argmin(d))
            labs.append(ref_lab.get(j) if d[j] < tol else None)
        out.append(labs)
    return out


def analyze_series(vol: np.ndarray, spacing_mm, params: AnalysisParams, mode: str = "active",
                   geometry_from: Optional[dict] = None) -> dict:
    """mode='active' – STIR/T2, гиперинтенсивные углы (активное воспаление);
    mode='chronic' – T1, жировые углы (экспериментально); для него геометрия берётся из результата STIR."""
    P = params
    from . import ml_hook
    disc_fn = ml_hook.disc_mask_fn() if P.use_ml else None
    clf = ml_hook.corner_clf_fn() if P.use_ml else None
    n = normalize_volume(vol)
    sp = float(np.mean(spacing_mm))
    slices = []
    all_vs, all_discs, all_canal = [], [], []
    gs = []
    for i in range(len(n)):
        g = smooth(n[i], P.smooth_sigma_mm, spacing_mm)
        gs.append(g)
        if geometry_from is None:
            dm = disc_fn(n[i]) if disc_fn else None
            discs, canal = find_discs(g, spacing_mm, P.disc_threshold, mask=dm)
            vs = build_vertebrae(discs, spacing_mm, g.shape)
        else:
            discs, canal, vs = [], None, None
        all_vs.append(vs); all_discs.append(discs)
    if geometry_from is None:
        real_counts = [sum(1 for v in vs if not v.extrapolated and v.width_mm >= P.min_body_width_mm) for vs in all_vs]
        labels = _assign_labels(all_vs, P.levels, [c >= P.min_vertebrae_per_slice for c in real_counts])
    gain = P.lesion_rel_gain if mode == "active" else T1_REL_GAIN

    for i in range(len(n)):
        entry = {"index": i, "informative": False, "reason": "", "n_vertebrae": 0, "vertebrae": [],
                 "raw_positive": False, "positive": False, "discs": []}
        if geometry_from is None:
            entry["discs"] = [np.array([d.pt(d.umin, d.vmin), d.pt(d.umax, d.vmin), d.pt(d.umax, d.vmax),
                                        d.pt(d.umin, d.vmax)]).round(1).tolist() for d in all_discs[i]]
        else:
            entry["discs"] = geometry_from["slices"][i].get("discs", [])
        if geometry_from is not None:
            gsl = geometry_from["slices"][i]
            entry["informative"] = gsl["informative"]; entry["reason"] = gsl["reason"]
            geo = [(np.array(v["quad"]), v["label"], v["extrapolated"]) for v in gsl["vertebrae"]]
        else:
            ok = real_counts[i] >= P.min_vertebrae_per_slice
            entry["informative"] = ok
            entry["reason"] = "" if ok else f"тел позвонков с видимыми углами: {real_counts[i]} (< {P.min_vertebrae_per_slice}) – срез пропущен"
            geo = [(v.quad, labels[i][j], v.extrapolated) for j, v in enumerate(all_vs[i])]
        entry["n_vertebrae"] = len(geo)
        if entry["informative"]:
            for quad, lab, extra in geo:
                if lab is None:
                    continue
                cs = CORNERS
                if extra == "down" and P.s1_superior_only:
                    cs = ("AS", "PS")
                elif extra == "up":
                    cs = ("AI", "PI")
                r = analyze_vertebra(gs[i], np.asarray(quad), spacing_mm, P, rel_gain=gain, corners=cs, clf=clf if mode == "active" else None)
                r.update({"label": lab, "quad": np.asarray(quad).round(1).tolist(), "extrapolated": extra})
                entry["vertebrae"].append(r)
        else:
            if geometry_from is None:
                entry["vertebrae"] = [{"label": labels[i][j], "quad": v.quad.round(1).tolist(), "extrapolated": v.extrapolated,
                                       "corners": {}, "ref": 0, "sigma": 0, "threshold": 0} for j, v in enumerate(all_vs[i])]
        pos = [f"{v['label']}-{k}" for v in entry["vertebrae"] for k, c in v["corners"].items() if c["positive"]]
        entry["positive_corners_raw"] = pos
        entry["raw_positive"] = bool(pos)
        slices.append(entry)
    return _aggregate(slices, P, mode)


def _aggregate(slices, P, mode):
    N = max(1, int(P.min_consecutive_slices))
    if mode == "chronic":
        N = max(N, 2)   # экспериментальный Т1-режим: одиночный срез не считается (шумит)
    keys = {}
    for s in slices:
        for v in s["vertebrae"]:
            for k, c in v["corners"].items():
                keys.setdefault((v["label"], k), {})[s["index"]] = c
    findings = []
    confirmed = {}
    for (lab, k), per in keys.items():
        pos_idx = sorted(i for i, c in per.items() if c["positive"])
        runs, cur = [], []
        for i in pos_idx:
            if cur and i == cur[-1] + 1:
                cur.append(i)
            else:
                if cur:
                    runs.append(cur)
                cur = [i]
        if cur:
            runs.append(cur)
        for r in runs:
            if len(r) >= N:
                for i in r:
                    confirmed.setdefault(i, []).append(f"{lab}-{k}")
                findings.append({"level": lab, "corner": k, "corner_ru": CORNER_RU[k], "slices": r,
                                 "max_area_mm2": max(per[i]["area_mm2"] for i in r),
                                 "max_contrast": max(per[i]["contrast"] for i in r)})
    for s in slices:
        s["confirmed_corners"] = sorted(confirmed.get(s["index"], []))
        s["positive"] = bool(s["confirmed_corners"])
    informative = [s["index"] for s in slices if s["informative"]]
    positive = [s["index"] for s in slices if s["positive"]]
    order = {l: i for i, l in enumerate(P.levels)}
    findings.sort(key=lambda f: (order.get(f["level"], 99), f["corner"]))
    study_pos = bool(findings)
    from .report import make_conclusion
    return {"version": VERSION, "mode": mode, "params": P.to_dict(), "slices": slices,
            "study": {"positive": study_pos, "informative_slices": informative, "positive_slices": positive,
                      "findings": findings, "n_informative": len(informative),
                      "conclusion": make_conclusion(study_pos, findings, informative, P, mode)}}
