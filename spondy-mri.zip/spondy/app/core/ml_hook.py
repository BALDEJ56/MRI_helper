"""Точки подключения обученных нейросетей (второй этап работы). Без моделей система работает на классическом методе.

  models/disc_seg.onnx      – сегментация дисков: вход [1,1,H,W] (норм. срез, 1.0≈p99.7), выход [1,1,H,W] логиты/вероятности
  models/corner_clf.onnx    – классификатор угла (ВКР, этап 2): вход [1,1,32,32] (патч угла, делённый на опорное значение
                               центра тела), выход [1,1] или [1,2] – вероятность «активный спондилит»
Модели обучаются скриптами tools/train_unet.py и tools/train_corner_clf.py на размеченной базе и экспортируются в ONNX.
Требуется пакет onnxruntime (необязательная зависимость)."""
from __future__ import annotations
import os
import numpy as np

MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models")
_cache = {}


def _session(name):
    path = os.path.join(MODEL_DIR, name)
    if not os.path.exists(path):
        return None
    if path not in _cache:
        try:
            import onnxruntime as ort
            _cache[path] = ort.InferenceSession(path, providers=["CPUExecutionProvider"])
        except Exception:
            _cache[path] = None
    return _cache[path]


def _sigmoid(x):
    return 1 / (1 + np.exp(-x))


def disc_mask_fn():
    """Возвращает функцию img_norm[H,W] -> bool-маска дисков, либо None, если модели нет."""
    s = _session("disc_seg.onnx")
    if s is None:
        return None
    inp = s.get_inputs()[0].name

    def f(img):
        out = s.run(None, {inp: img[None, None].astype(np.float32)})[0][0, 0]
        if out.min() < 0 or out.max() > 1:
            out = _sigmoid(out)
        return out > 0.5
    return f


def corner_clf_fn():
    """Возвращает функцию patch32x32 -> вероятность, либо None."""
    s = _session("corner_clf.onnx")
    if s is None:
        return None
    inp = s.get_inputs()[0].name

    def f(patch):
        out = np.asarray(s.run(None, {inp: patch[None, None].astype(np.float32)})[0]).ravel()
        p = out[-1]
        return float(_sigmoid(p) if (p < 0 or p > 1) else p)
    return f
