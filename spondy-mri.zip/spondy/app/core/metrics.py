"""Метрики качества [ВКР, гл.1 п.1.2.4 и гл.2 п.2.3]: Se, Sp, F1, каппа Коэна, AUC, DSC, IoU."""
import numpy as np


def confusion(y_true, y_pred):
    y_true, y_pred = np.asarray(y_true, bool), np.asarray(y_pred, bool)
    return dict(tp=int((y_true & y_pred).sum()), fp=int((~y_true & y_pred).sum()),
                fn=int((y_true & ~y_pred).sum()), tn=int((~y_true & ~y_pred).sum()))


def _div(a, b):
    return round(a / b, 3) if b else None


def classification_metrics(y_true, y_pred):
    c = confusion(y_true, y_pred)
    tp, fp, fn, tn = c["tp"], c["fp"], c["fn"], c["tn"]
    n = tp + fp + fn + tn
    se, sp = _div(tp, tp + fn), _div(tn, tn + fp)
    prec = _div(tp, tp + fp)
    f1 = _div(2 * tp, 2 * tp + fp + fn)
    kappa = None
    if n:
        po = (tp + tn) / n
        pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (n * n)
        kappa = round((po - pe) / (1 - pe), 3) if pe != 1 else None
    return {**c, "n": n, "sensitivity": se, "specificity": sp, "precision": prec, "f1": f1, "kappa": kappa,
            "accuracy": _div(tp + tn, n)}


def dice(a, b):
    a, b = np.asarray(a, bool), np.asarray(b, bool)
    s = a.sum() + b.sum()
    return 1.0 if s == 0 else float(2 * (a & b).sum() / s)


def iou(a, b):
    a, b = np.asarray(a, bool), np.asarray(b, bool)
    u = (a | b).sum()
    return 1.0 if u == 0 else float((a & b).sum() / u)


def auc(y_true, scores):
    from sklearn.metrics import roc_auc_score
    y_true = np.asarray(y_true, int)
    if len(set(y_true.tolist())) < 2:
        return None
    return round(float(roc_auc_score(y_true, scores)), 3)


# Целевые значения из ВКР (гл.1, п.1.2.4): Se ≥ 0.85, Sp ≥ 0.80, AUC ≥ 0.85, DSC ≥ 0.75
TARGETS = {"sensitivity": 0.85, "specificity": 0.80, "auc": 0.85, "dsc": 0.75}
