"""Чтение DICOM (файлы, папки, zip), группировка в серии, классификация режимов,
приведение объёма к канонической ориентации (перед – слева, краниально – вверх)."""
from __future__ import annotations
import io, os, zipfile, hashlib
from dataclasses import dataclass
from typing import Dict, List, Optional
import numpy as np
import pydicom


@dataclass
class Series:
    series_uid: str
    study_uid: str
    description: str
    plane: str
    weighting: str              # STIR / T1 / T2 / OTHER / LOCALIZER
    manufacturer: str
    model: str
    device_key: str
    field_strength: Optional[float]
    study_date: str
    rows: int
    cols: int
    spacing_mm: tuple
    slice_thickness: Optional[float]
    slice_gap: Optional[float]
    tr: Optional[float]
    te: Optional[float]
    ti: Optional[float]
    region_guess: str
    patient_sex: str = ""
    patient_age: str = ""
    volume: Optional[np.ndarray] = None
    flipped_lr: bool = False
    flipped_ud: bool = False
    n_slices: int = 0

    def meta(self) -> dict:
        keys = ("series_uid", "study_uid", "description", "plane", "weighting", "manufacturer", "model",
                "device_key", "field_strength", "study_date", "rows", "cols", "slice_thickness", "slice_gap",
                "tr", "te", "ti", "region_guess", "n_slices", "flipped_lr", "flipped_ud")
        d = {k: getattr(self, k) for k in keys}
        d["spacing_mm"] = list(self.spacing_mm)
        return d


def _f(x):
    try:
        return float(x)
    except Exception:
        return None


def device_key(manufacturer: str, model: str, field_t) -> str:
    m = (manufacturer or "").upper()
    brand = "GE" if ("GE" in m or "GENERAL" in m) else "Philips" if "PHILIPS" in m else \
        "Siemens" if "SIEMENS" in m else (manufacturer or "Unknown").title()
    ft = f" {field_t:g}T" if field_t else ""
    return f"{brand} {model or ''}{ft}".replace("  ", " ").strip()


def classify_weighting(desc, tr, te, ti, seq) -> str:
    d = (desc or "").upper()
    if isinstance(seq, str):
        seq = [seq]
    seq = [str(s).upper() for s in (seq or [])]
    if "LOCALIZER" in d or "SCOUT" in d:
        return "LOCALIZER"
    if "STIR" in d or "TIRM" in d:
        return "STIR"
    if ti and ti > 50 and "IR" in seq:
        return "STIR"
    if "T1" in d:
        return "T1"
    if "T2" in d:
        return "T2"
    if tr and te:
        if tr < 900 and te < 30:
            return "T1"
        if tr > 1500 and te > 60:
            return "T2"
    return "OTHER"


def plane_from_iop(iop) -> str:
    try:
        n = np.cross(np.array(iop[:3], float), np.array(iop[3:], float))
        return ["sagittal", "coronal", "axial"][int(np.argmax(np.abs(n)))]
    except Exception:
        return "unknown"


def region_from_text(desc: str, body: str) -> str:
    t = f"{desc or ''} {body or ''}".upper()
    if any(k in t for k in ("SIJ", "SACROIL", "SI JOINT", "КПС")):
        return "sij"
    return "lumbar"


def _read(src):
    try:
        ds = pydicom.dcmread(src, force=True)
        if "PixelData" not in ds:
            return None
        _ = ds.Rows, ds.Columns, ds.pixel_array
        return ds
    except Exception:
        return None


def _iter_paths(paths):
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in sorted(files):
                    yield os.path.join(root, f)
        else:
            yield p


_SKIP = (".exe", ".dll", ".txt", ".png", ".jpg", ".json", ".csv")


def read_datasets(paths: List[str]) -> List[pydicom.Dataset]:
    """Файлы, папки и .zip (zip читается в памяти, пути с '..' пропускаются)."""
    out = []
    for p in _iter_paths(paths):
        low = p.lower()
        if low.endswith(".zip"):
            with zipfile.ZipFile(p) as z:
                for info in z.infolist():
                    name = info.filename.replace("\\", "/")
                    if info.is_dir() or info.file_size == 0 or info.file_size > 400 * 2 ** 20 or ".." in name.split("/"):
                        continue
                    base = os.path.basename(name).lower()
                    if base in ("dicomdir", "readme") or base.endswith(_SKIP):
                        continue
                    ds = _read(io.BytesIO(z.read(info)))
                    if ds is not None:
                        out.append(ds)
        else:
            if os.path.basename(low) in ("dicomdir", "readme") or low.endswith(_SKIP):
                continue
            ds = _read(p)
            if ds is not None:
                out.append(ds)
    return out


def _canonical(vol, iop):
    """Сагиттальные срезы: перед (−y в LPS) – слева; краниально (+z) – вверх."""
    r = np.array(iop[:3], float)   # куда растёт индекс столбца
    c = np.array(iop[3:], float)   # куда растёт индекс строки
    flip_lr = bool(r[1] < 0)       # столбцы растут вперёд → перед справа → отражаем
    flip_ud = bool(c[2] > 0)       # строки растут краниально → верх внизу → отражаем
    if flip_lr:
        vol = vol[:, :, ::-1]
    if flip_ud:
        vol = vol[:, ::-1, :]
    return np.ascontiguousarray(vol), flip_lr, flip_ud


def build_series(datasets: List[pydicom.Dataset], load_pixels=True) -> List[Series]:
    groups: Dict[str, List[pydicom.Dataset]] = {}
    for ds in datasets:
        if str(getattr(ds, "Modality", "MR")) not in ("MR", ""):
            continue
        groups.setdefault(str(ds.get("SeriesInstanceUID", "unknown")), []).append(ds)
    res: List[Series] = []
    for suid, lst in groups.items():
        d0 = lst[0]
        iop = [float(x) for x in d0.get("ImageOrientationPatient", [1, 0, 0, 0, 1, 0])]
        plane = plane_from_iop(iop)
        nrm = np.cross(iop[:3], iop[3:])
        ax = int(np.argmax(np.abs(nrm)))      # ось, вдоль которой идут срезы (x: сагиттально, y: корон., z: аксиально)

        def pos(d):
            # порядок срезов не зависит от знака нормали и от производителя: по возрастанию координаты LPS вдоль оси
            ipp = d.get("ImagePositionPatient")
            return float(ipp[ax]) if ipp is not None else float(d.get("InstanceNumber", 0))
        lst.sort(key=pos)
        arr = []
        for d in lst:
            a = d.pixel_array.astype(np.float32)
            arr.append(a * float(d.get("RescaleSlope", 1) or 1) + float(d.get("RescaleIntercept", 0) or 0))
        if len({a.shape for a in arr}) != 1:
            continue
        vol = np.stack(arr)
        ps = [float(x) for x in d0.get("PixelSpacing", [1.0, 1.0])]
        fl = _f(d0.get("MagneticFieldStrength"))
        desc = str(d0.get("SeriesDescription", d0.get("ProtocolName", "")))
        tr, te, ti = _f(d0.get("RepetitionTime")), _f(d0.get("EchoTime")), _f(d0.get("InversionTime"))
        wt = classify_weighting(desc, tr, te, ti, d0.get("ScanningSequence", ""))
        flr = fud = False
        if plane == "sagittal":
            vol, flr, fud = _canonical(vol, iop)
        manu, model = str(d0.get("Manufacturer", "")), str(d0.get("ManufacturerModelName", ""))
        res.append(Series(
            series_uid=suid, study_uid=str(d0.get("StudyInstanceUID", "")), description=desc, plane=plane,
            weighting=wt, manufacturer=manu, model=model, device_key=device_key(manu, model, fl), field_strength=fl,
            study_date=str(d0.get("StudyDate", "")), rows=int(d0.Rows), cols=int(d0.Columns),
            spacing_mm=(ps[0], ps[1]), slice_thickness=_f(d0.get("SliceThickness")),
            slice_gap=_f(d0.get("SpacingBetweenSlices")), tr=tr, te=te, ti=ti,
            region_guess=region_from_text(desc, str(d0.get("BodyPartExamined", ""))),
            patient_sex=str(d0.get("PatientSex", "") or ""), patient_age=str(d0.get("PatientAge", "") or ""),
            volume=vol if load_pixels else None, flipped_lr=flr, flipped_ud=fud, n_slices=vol.shape[0]))
    return res


def load_series_from_paths(paths: List[str]) -> List[Series]:
    return build_series(read_datasets(paths))


def volume_hash(vol: np.ndarray) -> str:
    return hashlib.sha1(np.ascontiguousarray(vol[:: max(1, len(vol) // 4)]).tobytes()).hexdigest()[:16]
