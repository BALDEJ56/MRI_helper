"""Классическая (не обучаемая) локализация межпозвонковых дисков и построение тел позвонков
на сагиттальном срезе. Это базовый метод: тот же интерфейс (find_discs → build_vertebrae) принимает
маски диска от нейросети (app/core/ml_hook.py), когда модель будет обучена на размеченных данных."""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
import numpy as np
from scipy import ndimage as ndi
from skimage import measure


@dataclass
class Disc:
    c: np.ndarray       # центр (x, y), px
    u: np.ndarray       # единичный вектор вдоль диска, вперёд→назад (x>0)
    v: np.ndarray       # единичный вектор вниз
    umin: float
    umax: float
    vmin: float
    vmax: float
    area_mm2: float

    def pt(self, pu, pv):
        return self.c + self.u * pu + self.v * pv


@dataclass
class Vertebra:
    quad: np.ndarray    # [AS, PS, PI, AI] в px: перед-верх, зад-верх, зад-низ, перед-низ
    extrapolated: str   # '' | 'up' | 'down'
    height_mm: float
    width_mm: float


def _canal_mask(g, sp):
    """Самый высокий яркий узкий компонент = спинномозговой канал с ликвором (если виден на срезе)."""
    m = g > 0.6
    lab, n = ndi.label(m)
    best, bh = 0, 0
    H, W = g.shape
    for k, sl in enumerate(ndi.find_objects(lab), 1):
        h = (sl[0].stop - sl[0].start) * sp
        w = (sl[1].stop - sl[1].start) * sp
        if h > bh and h > 70 and w < 60 and 0.25 * W < (sl[1].start + sl[1].stop) / 2 < 0.8 * W:
            best, bh = k, h
    return (lab == best) if best else np.zeros_like(m)


def find_discs(g: np.ndarray, spacing_mm, thr: float = 0.40, mask=None):
    """g – сглаженный срез, нормированный (1.0 ≈ p99.7 серии). Возвращает (список Disc, маска канала)."""
    sp = float(np.mean(spacing_mm))
    canal = _canal_mask(g, sp)
    canal_d = ndi.binary_dilation(canal, iterations=2) if canal.any() else canal
    discs: List[Disc] = []
    for t in (thr, thr * 0.75):
        if mask is not None:                       # маска диска от нейросети (ml_hook.disc_mask_fn)
            m = np.asarray(mask, bool)
        else:
            m = (g > t) & ~canal_d
        m = ndi.binary_opening(m, iterations=1)
        lab = measure.label(m, connectivity=2)
        cand = []
        for r in measure.regionprops(lab):
            area = r.area * sp * sp
            if not (40 <= area <= 1000):
                continue
            coords = r.coords
            # адаптивный порог по собственной яркости диска: отсекает прилежащий очаг отёка (менее яркий, чем диск)
            vals = g[coords[:, 0], coords[:, 1]]
            keep = vals >= max(t, 0.65 * np.percentile(vals, 90))
            if keep.sum() >= 0.5 * len(vals):
                sub = np.zeros(g.shape, bool); sub[coords[keep, 0], coords[keep, 1]] = True
                sub = ndi.binary_opening(sub, iterations=1)
                l2 = measure.label(sub, connectivity=2)
                if l2.max() == 0:
                    continue
                rr = max(measure.regionprops(l2), key=lambda q: q.area)
                coords, area = rr.coords, rr.area * sp * sp
                if area < 40 or rr.solidity < 0.65:
                    continue
            elif r.solidity < 0.65:
                continue
            ys, xs = coords[:, 0].astype(float), coords[:, 1].astype(float)
            pts = np.stack([xs, ys], 1)
            c = pts.mean(0)
            cov = np.cov((pts - c).T)
            w, vec = np.linalg.eigh(cov)
            e1 = vec[:, 1]
            if e1[0] < 0:
                e1 = -e1
            L1, L2 = 4 * np.sqrt(max(w[1], 1e-9)) * sp, 4 * np.sqrt(max(w[0], 1e-9)) * sp
            ang = np.degrees(np.arctan2(e1[1], e1[0]))
            if not (14 <= L1 <= 65 and 1.5 <= L2 <= 22 and L1 / L2 >= 1.6 and abs(ang) <= 58):
                continue
            fr = _robust_frame(pts, c, e1, sp)
            if fr is None:
                continue
            u, v, pc, umin, umax, vmin, vmax = fr
            cand.append(Disc(pc, u, v, umin, umax, vmin, vmax, area))
        if len(cand) >= 4 or t != thr:
            if len(cand) >= len(discs):
                discs = cand
            break
        discs = cand
    discs = _column_filter(discs, sp)
    discs.sort(key=lambda d: d.c[1])
    return discs, canal



def _robust_frame(pts, c, e1, sp):
    """Рамка диска по его ЦЕНТРАЛЬНОЙ части: прилежащий к углу яркий очаг отёка (выступ у края блока)
    не должен менять ориентацию/толщину диска. Возвращает (u, v, центр, umin, umax, vmin, vmax)."""
    u = e1 / np.linalg.norm(e1)
    for _ in range(2):
        v = np.array([-u[1], u[0]])
        pu, pv = (pts - c) @ u, (pts - c) @ v
        lo, hi = np.percentile(pu, 2), np.percentile(pu, 98)
        core = (pu > lo + 0.2 * (hi - lo)) & (pu < hi - 0.2 * (hi - lo))
        if core.sum() < 12:
            return None
        bins = np.floor(pu[core] / 1.0).astype(int)
        cen, thick, xs = [], [], []
        for b in np.unique(bins):
            sel = pv[core][bins == b]
            if sel.size >= 2:
                cen.append((sel.max() + sel.min()) / 2); thick.append(sel.max() - sel.min() + 1); xs.append(b + .5)
        if len(xs) < 4:
            return None
        xs_a, ce_a = np.array(xs), np.array(cen)
        sl = [(ce_a[j] - ce_a[i]) / (xs_a[j] - xs_a[i]) for i in range(len(xs_a)) for j in range(i + 1, len(xs_a)) if xs_a[j] != xs_a[i]]
        slope = float(np.median(sl)) if sl else 0.0          # Theil–Sen: устойчив к выступу-очагу
        u = u + slope * np.array([-u[1], u[0]])
        u = u / np.linalg.norm(u)
    v = np.array([-u[1], u[0]])
    pu, pv = (pts - c) @ u, (pts - c) @ v
    lo, hi = np.percentile(pu, 2), np.percentile(pu, 98)
    core = (pu > lo + 0.2 * (hi - lo)) & (pu < hi - 0.2 * (hi - lo))
    pvc = pv[core]
    T = float(np.percentile(pvc, 97) - np.percentile(pvc, 3)) + 1.0
    v0 = float(np.median(pvc))
    keep = np.abs(pv - v0) <= 0.5 * T * 1.2 + 0.5 / sp
    if keep.sum() < 12:
        return None
    pu2 = pu[keep]
    umin, umax = float(np.percentile(pu2, 2)), float(np.percentile(pu2, 98))
    return u, v, c.copy(), umin, umax, v0 - 0.5 * T, v0 + 0.5 * T


def _column_filter(discs: List[Disc], sp: float):
    """Диски лежат в одном вертикальном «столбе»: отбрасываем выбросы по x (кишка, сосуды и т.п.)."""
    if len(discs) < 3:
        return discs
    xs = np.array([d.c[0] for d in discs]); ys = np.array([d.c[1] for d in discs])
    keep = np.ones(len(discs), bool)
    for _ in range(3):
        if keep.sum() >= 4:
            co = np.polyfit(ys[keep], xs[keep], 1)
            res = xs - np.polyval(co, ys)
        else:
            res = xs - np.median(xs[keep])
        keep = np.abs(res) < 14 / sp
        if keep.sum() < 2:
            break
    return [d for d, k in zip(discs, keep) if k]


def build_vertebrae(discs: List[Disc], spacing_mm, shape) -> List[Vertebra]:
    sp = float(np.mean(spacing_mm))
    H, W = shape
    out: List[Vertebra] = []
    pairs = []
    for a, b in zip(discs[:-1], discs[1:]):
        dist = np.linalg.norm(b.c - a.c) * sp
        if not (24 <= dist <= 58):
            continue
        # верхняя граница – нижний край верхнего диска; нижняя – верхний край нижнего диска
        AS, PS = a.pt(a.umin, a.vmax), a.pt(a.umax, a.vmax)
        AI, PI = b.pt(b.umin, b.vmin), b.pt(b.umax, b.vmin)
        q = np.array([AS, PS, PI, AI])
        h = (np.linalg.norm(AI - AS) + np.linalg.norm(PI - PS)) / 2 * sp
        w = (np.linalg.norm(PS - AS) + np.linalg.norm(PI - AI)) / 2 * sp
        if 22 <= h <= 45 and 10 <= w <= 65:
            out.append(Vertebra(q, "", h, w))
            pairs.append((a, b))
    if not out:
        return out
    hm = float(np.median([v.height_mm for v in out]))
    # S1: ниже самого нижнего диска (L5–S1), если он ближе к низу изображения; Th12: выше верхнего диска
    last, first = pairs[-1][1], pairs[0][0]   # диск под нижним и над верхним реальным телом (L5–S1 и т.д.)
    dn = last.v * (hm * 0.9 / sp)
    AS, PS = last.pt(last.umin, last.vmax), last.pt(last.umax, last.vmax)
    q = np.array([AS, PS, PS + dn, AS + dn])
    if q[:, 1].max() < H - 2:
        out.append(Vertebra(q, "down", hm * 0.9, np.linalg.norm(PS - AS) * sp))
    up = first.v * (hm / sp)
    AI, PI = first.pt(first.umin, first.vmin), first.pt(first.umax, first.vmin)
    q = np.array([AI - up, PI - up, PI, AI])
    if q[:, 1].min() > 2:
        out.insert(0, Vertebra(q, "up", hm, np.linalg.norm(PI - AI) * sp))
    return out
