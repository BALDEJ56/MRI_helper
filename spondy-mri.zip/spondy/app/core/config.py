"""Параметры анализа. Все значения можно менять из веб-интерфейса (Настройки).
Обоснование каждого значения: docs/TRACEABILITY.md."""
from dataclasses import dataclass, field, asdict, fields
from typing import List

# Th12..S1 = 7 позвонков: [3_1.docx: «Шесть?» → «Семь? Ну, семь, наверное, придётся»];
# [2.docx 00:01:51] L1–L5 + S1; [2.docx 00:02:42] «нижние Th12 и верхний S1».
DEFAULT_LEVELS = ["Th12", "L1", "L2", "L3", "L4", "L5", "S1"]


@dataclass
class AnalysisParams:
    # отбор срезов [3_1.docx: «программа сама должна определить, что там нету»]
    min_vertebrae_per_slice: int = 4
    min_body_width_mm: float = 15.0       # на боковых срезах тело позвонка узкое → углы не видны
    # сегментация дисков (классический базовый метод)
    disc_threshold: float = 0.40          # доля от p99.7 по серии
    smooth_sigma_mm: float = 0.8
    # угловые зоны
    corner_size_mm: float = 12.0          # в гл.1 ВКР ROI ≈ 15×15 мм; берём 12 мм внутри тела
    corner_margin_mm: float = 1.0
    corner_margin_posterior_mm: float = 2.5   # рядом канал с ликвором [2.docx 00:02:13]
    # правило «повышенный сигнал в углу относительно центра тела» [2.docx 00:07:59–00:08:25]
    lesion_rel_gain: float = 1.6
    lesion_k_sigma: float = 3.0
    min_lesion_area_mm2: float = 4.0
    max_csf_level: float = 0.85
    # 1 срез [2.docx 00:07:17]; 2–3 подряд [2.docx 00:06:56]
    min_consecutive_slices: int = 1
    levels: List[str] = field(default_factory=lambda: list(DEFAULT_LEVELS))
    s1_superior_only: bool = True
    use_ml: bool = True                   # использовать обученные модели из models/, если они есть
    clf_threshold: float = 0.5            # порог вероятности классификатора угла (если модель подключена)

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in (d or {}).items() if k in names})
