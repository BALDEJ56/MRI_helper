"""Предобработка: нормализация яркости (межаппаратная вариабельность [2.docx 00:00:54–00:01:21])."""
import numpy as np
from scipy import ndimage as ndi

LANDMARK_PCTS = (1, 10, 25, 50, 75, 90, 99)


def robust_scale(vol: np.ndarray) -> float:
    """Опорное значение серии – p99.7 по центральным срезам (не зависит от абсолютной шкалы аппарата)."""
    n = len(vol)
    core = vol[n // 4: max(n // 4 + 1, 3 * n // 4)]
    return float(max(np.percentile(core, 99.7), 1e-6))


def normalize_volume(vol: np.ndarray) -> np.ndarray:
    return vol.astype(np.float32) / robust_scale(vol)


def foreground_values(vol, thr_rel=0.03):
    ref = robust_scale(vol)
    v = vol[vol > thr_rel * ref]
    return v


def landmarks(vol: np.ndarray):
    v = foreground_values(vol)
    return [float(np.percentile(v, p)) for p in LANDMARK_PCTS] if v.size else [0.0] * len(LANDMARK_PCTS)


def nyul_apply(vol: np.ndarray, std_landmarks):
    """Кусочно-линейное приведение перцентилей к эталонным (Nyul–Udupa).
    std_landmarks – средние перцентили по обучающей выборке (tools/learn_landmarks.py)."""
    src = landmarks(vol)
    xs = np.array([0.0] + src + [max(src[-1] * 1.5, vol.max())])
    ys = np.array([0.0] + list(std_landmarks) + [std_landmarks[-1] * 1.5])
    xs = np.maximum.accumulate(xs + np.arange(len(xs)) * 1e-9)
    return np.interp(vol, xs, ys).astype(np.float32)


def smooth(a: np.ndarray, sigma_mm: float, spacing_mm) -> np.ndarray:
    s = sigma_mm / float(np.mean(spacing_mm))
    return ndi.gaussian_filter(a, max(s, 0.3))


def window_to_uint8(a: np.ndarray, wc=None, ww=None) -> np.ndarray:
    if wc is None or ww is None:
        lo, hi = np.percentile(a, 1), np.percentile(a, 99.7)
    else:
        lo, hi = wc - ww / 2, wc + ww / 2
    if hi <= lo:
        hi = lo + 1
    return (np.clip((a - lo) / (hi - lo), 0, 1) * 255).astype(np.uint8)
