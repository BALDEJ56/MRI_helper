"""Угловые зоны позвонка и правило «повышенный сигнал в углу относительно центра тела».
Тело позвонка «выпрямляется» в прямоугольный патч 0.5 мм/пкс; анализ идёт только внутри патча,
поэтому соседние структуры (аорта, сосуды, канал) в расчёт не попадают [2.docx 00:13:37, 00:13:51]."""
from __future__ import annotations
import numpy as np, cv2
from scipy import ndimage as ndi

RES = 0.5  # мм на пиксель патча
CORNERS = ("AS", "PS", "AI", "PI")   # перед-верх, зад-верх, перед-низ, зад-низ
CORNER_RU = {"AS": "передне-верхний", "PS": "задне-верхний", "AI": "передне-нижний", "PI": "задне-нижний"}


def straighten(g, quad, spacing_mm):
    sp = float(np.mean(spacing_mm))
    Wp = max(int(round(np.mean([np.linalg.norm(quad[1] - quad[0]), np.linalg.norm(quad[2] - quad[3])]) * sp / RES)), 8)
    Hp = max(int(round(np.mean([np.linalg.norm(quad[3] - quad[0]), np.linalg.norm(quad[2] - quad[1])]) * sp / RES)), 8)
    src = quad.astype(np.float32)
    dst = np.array([[0, 0], [Wp, 0], [Wp, Hp], [0, Hp]], np.float32)
    M = cv2.getPerspectiveTransform(src, dst)
    patch = cv2.warpPerspective(g.astype(np.float32), M, (Wp, Hp), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    return patch, np.linalg.inv(M)


def _back(pts, Minv):
    p = np.asarray(pts, np.float32).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(p, Minv).reshape(-1, 2)


def corner_patch(patch, roi, ref, size=32):
    x0, y0, x1, y1 = roi
    c = cv2.resize(patch[y0:y1, x0:x1], (size, size), interpolation=cv2.INTER_AREA)
    return (c / max(ref, 1e-6)).astype(np.float32)


def corner_rois(Wp, Hp, P):
    L = int(min(P.corner_size_mm / RES, 0.45 * min(Wp, Hp)))
    m = int(round(P.corner_margin_mm / RES))
    mp = int(round(P.corner_margin_posterior_mm / RES))
    return {
        "AS": (m, m, m + L, m + L),
        "PS": (Wp - mp - L, m, Wp - mp, m + L),
        "AI": (m, Hp - m - L, m + L, Hp - m),
        "PI": (Wp - mp - L, Hp - m - L, Wp - mp, Hp - m),
    }   # (x0, y0, x1, y1) в патче


def analyze_vertebra(g, quad, spacing_mm, P, rel_gain=None, corners=CORNERS, clf=None):
    patch, Minv = straighten(g, quad, spacing_mm)
    Hp, Wp = patch.shape
    c = patch[int(.3 * Hp):int(.7 * Hp) + 1, int(.3 * Wp):int(.7 * Wp) + 1]
    # центр тела – внутренний референс (не зависит от аппарата); самые яркие 20 % (питающие вены,
    # гемангиомы в центре) исключаются: они в норме и оцениваться не должны [2.docx 00:03:30–00:04:11]
    c = c[c <= np.percentile(c, 80)]
    ref = float(np.median(c))
    sigma = float(1.4826 * np.median(np.abs(c - ref)))
    gain = P.lesion_rel_gain if rel_gain is None else rel_gain
    thr = max(ref * gain, ref + P.lesion_k_sigma * sigma)
    rois = corner_rois(Wp, Hp, P)
    res = {"ref": ref, "sigma": sigma, "threshold": thr, "corners": {}}
    for k in corners:
        x0, y0, x1, y1 = rois[k]
        roi = patch[y0:y1, x0:x1]
        mask = (roi > thr) & (roi < P.max_csf_level)
        mask = ndi.binary_opening(mask, iterations=1) | (mask & False)
        lab, n = ndi.label(mask)
        best, area_px = 0, 0
        for i in range(1, n + 1):
            a = int((lab == i).sum())
            if a > area_px:
                best, area_px = i, a
        area = area_px * RES * RES
        comp = lab == best if best else np.zeros_like(mask)
        contrast = float(roi[comp].mean() / max(ref, 1e-6)) if best else 0.0
        positive = bool(area >= P.min_lesion_area_mm2)
        prob = None
        if clf is not None:       # этап 2 ВКР: классификатор по патчу угла 32×32, нормированному на центр тела
            prob = float(clf(corner_patch(patch, (x0, y0, x1, y1), ref)))
            positive = prob >= P.clf_threshold
        contour = None
        if best:
            full = np.zeros(patch.shape, np.uint8)
            full[y0:y1, x0:x1][comp] = 1
            cs, _ = cv2.findContours(full, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if cs:
                cnt = max(cs, key=cv2.contourArea)
                contour = _back(cv2.approxPolyDP(cnt, 0.8, True)[:, 0, :], Minv).round(1).tolist()
        roi_poly = _back([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], Minv).round(1).tolist()
        res["corners"][k] = {"positive": positive, "area_mm2": round(area, 1), "contrast": round(contrast, 2), "prob": prob,
                             "contour": contour, "roi": roi_poly}
    return res
