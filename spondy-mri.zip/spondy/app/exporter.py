"""Экспорт размеченных данных для обучения: изображения + маски по классам + manifest.json.
Разбиение 70/15/15 на уровне ПАЦИЕНТОВ (все срезы пациента – в одной части) [ВКР, гл.2, п.2.1: Train 70% / Val 15% / Test 15%]."""
import io, os, json, zipfile, hashlib
import numpy as np, cv2
from .core.preprocess import normalize_volume

CLASSES = {"body": "тела позвонков", "disc": "межпозвонковые диски", "lesion": "очаги активного спондилита"}


def split_of(code: str, seed="spondy") -> str:
    h = int(hashlib.sha1((seed + code).encode()).hexdigest(), 16) % 100
    return "train" if h < 70 else "val" if h < 85 else "test"


def slice_to_png(vol, i):
    n = normalize_volume(vol)
    return cv2.imencode(".png", (np.clip(n[i] / 1.2, 0, 1) * 255).astype(np.uint8))[1].tobytes()


def build_dataset_zip(db, ann_dir, load_vol, with_split=True):
    buf = io.BytesIO()
    manifest = []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        sers = db.execute("""SELECT s.id sid, s.vol_file, s.weighting, s.meta_json, p.code, st.device_key FROM series s
            JOIN studies st ON st.id=s.study_id JOIN patients p ON p.id=st.patient_id
            WHERE s.id IN (SELECT DISTINCT series_id FROM annotations)""").fetchall()
        for s in sers:
            vol = load_vol(s["vol_file"])
            meta = json.loads(s["meta_json"])
            for r in db.execute("SELECT DISTINCT slice_index FROM annotations WHERE series_id=? ORDER BY slice_index", (s["sid"],)):
                i = r["slice_index"]
                if i >= len(vol):
                    continue
                base = f"{s['code']}_s{s['sid']}_{i:02d}"
                z.writestr(f"images/{base}.png", slice_to_png(vol, i))
                present = []
                for a in db.execute("SELECT cls,file FROM annotations WHERE series_id=? AND slice_index=?", (s["sid"], i)):
                    fp = os.path.join(ann_dir, a["file"])
                    if os.path.exists(fp):
                        z.write(fp, f"masks/{base}_{a['cls']}.png"); present.append(a["cls"])
                manifest.append({"image": f"images/{base}.png", "patient": s["code"], "series_id": s["sid"], "slice": i,
                                 "weighting": s["weighting"], "device": s["device_key"], "spacing_mm": meta.get("spacing_mm"),
                                 "classes": present, "split": split_of(s["code"]) if with_split else None})
        z.writestr("manifest.json", json.dumps({"classes": CLASSES, "items": manifest}, ensure_ascii=False, indent=1))
    buf.seek(0)
    return buf, len(manifest)
