/* Просмотрщик исследования: серии, наложение результата, анализ, заключение врача, разметка */
const CLS = {body: {ru: 'Тела позвонков', color: '#ff6fb5'}, disc: {ru: 'Диски', color: '#ffd23f'}, lesion: {ru: 'Очаги', color: '#ff3b30'}};
let S = null;

async function viewStudy(sid) {
  const d = await api('GET', '/api/studies/' + sid);
  const params = await api('GET', '/api/settings/params');
  const pat = await api('GET', '/api/patients').then(l => l.find(p => p.code === d.study.patient_code));
  S = {sid, study: d.study, patientId: pat ? pat.id : null, series: d.series, analysesList: d.analyses, params,
    cur: null, idx: 0, win: null, an: {}, ov: {vert: true, corners: true, lesions: true, labels: true, discs: false},
    mode: 'view', ann: {cls: 'body', brush: 7, erase: false, canv: {}, dirty: false, existing: {}, drawing: false, last: null},
    docPos: null, docLabels: {}, img: new Image(), lo: null, hi: null};
  const pref = d.series.find(s => s.weighting === 'STIR' && s.plane === 'sagittal') || d.series.find(s => s.plane === 'sagittal') || d.series[0];
  shell('registry', h('div', {id: 'vroot'}));
  if (!pref) { document.getElementById('vroot').append(h('div', {class: 'card'}, 'В исследовании нет серий.')); return; }
  await selectSeries(pref.id);
  window.onkeydown = e => {
    if (!document.getElementById('vcanvas') || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') gotoSlice(S.idx + 1);
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') gotoSlice(S.idx - 1);
  };
}

async function selectSeries(id) {
  if (S.ann.dirty) await saveAnn();
  S.cur = S.series.find(s => s.id === id); S.idx = Math.floor(S.cur.n_slices / 2);
  S.win = await api('GET', `/api/series/${id}/window`); S.lo = S.win.lo; S.hi = S.win.hi;
  const mine = S.analysesList.filter(a => a.series_id === id);
  if (mine.length && !S.an[id]) S.an[id] = await api('GET', '/api/analyses/' + mine[0].id);
  const act = S.analysesList.find(a => a.mode === 'active');
  if (act && !Object.values(S.an).some(a => a.id === act.id)) S.an['active'] = await api('GET', '/api/analyses/' + act.id);
  const A = activeAnalysis();
  if (A && A.verdict) { S.docPos = A.verdict.positive === null ? null : !!A.verdict.positive; S.docLabels = {...A.verdict.slice_labels}; }
  S.ann.existing = await api('GET', `/api/series/${id}/annotations`);
  S.ann.canv = {};
  render(); await loadSlice();
}
const activeAnalysis = () => Object.values(S.an).find(a => a.mode === 'active') || null;
const curAnalysis = () => Object.values(S.an).find(a => a.series_id === S.cur.id) || null;

function render() {
  const root = document.getElementById('vroot'); const A = curAnalysis();
  const canvas = h('canvas', {id: 'vcanvas', width: S.cur.meta.cols, height: S.cur.meta.rows});
  canvas.addEventListener('wheel', e => { e.preventDefault(); gotoSlice(S.idx + (e.deltaY > 0 ? 1 : -1)); }, {passive: false});
  canvas.addEventListener('pointerdown', annDown); canvas.addEventListener('pointermove', annMove); window.addEventListener('pointerup', annUp);
  const slider = h('input', {type: 'range', min: 0, max: S.cur.n_slices - 1, value: S.idx, id: 'vslider', oninput: e => gotoSlice(+e.target.value)});
  const lo = h('input', {type: 'range', min: S.win.min, max: S.win.max, step: 1, value: S.lo, oninput: e => { S.lo = +e.target.value; refreshImg(); }});
  const hi = h('input', {type: 'range', min: S.win.min, max: S.win.max, step: 1, value: S.hi, oninput: e => { S.hi = +e.target.value; refreshImg(); }});
  const ck = (k, t) => h('label', {}, h('input', {type: 'checkbox', checked: S.ov[k], onchange: e => { S.ov[k] = e.target.checked; draw(); }}), t);
  const left = h('div', {}, h('div', {class: 'stage'}, canvas,
    h('div', {class: 'tools'}, h('label', {}, 'Срез ', slider, h('span', {id: 'vnum'})), h('label', {}, 'Яркость ', lo, hi),
      h('button', {onclick: () => { S.lo = S.win.lo; S.hi = S.win.hi; render(); loadSlice(); }}, 'сброс окна')),
    h('div', {class: 'tools'}, ck('vert', 'позвонки'), ck('labels', 'подписи'), ck('corners', 'угловые зоны'), ck('lesions', 'очаги'), ck('discs', 'диски'),
      h('span', {class: 'legend'}, h('i', {style: 'background:#2ecc71'}), 'тело', h('i', {style: 'background:#f1c40f'}), 'по продолжению', h('i', {style: 'background:#ff3b30'}), 'очаг')),
    h('div', {class: 'strip', id: 'vstrip'})), h('div', {class: 'mut small', style: 'margin-top:6px'}, 'Колесо мыши / стрелки – листать срезы. Серый – срез неинформативен, зелёный – признаков нет, красный – признак подтверждён, оранжевый – есть на срезе, но не выполнено правило «N подряд». Белая точка – ваша отметка среза.'));
  root.replaceChildren(h('div', {class: 'row'}, h('h1', {class: 'grow'}, `Исследование · пациент ${S.study.patient_code}`),
    S.patientId ? h('a', {href: '#/patient/' + S.patientId}, '← к карточке пациента') : null), h('div', {class: 'viewer'}, left, h('div', {id: 'vpanel'})));
  S.canvas = canvas; S.ctx = canvas.getContext('2d'); renderPanel(); renderStrip();
}

function renderStrip() {
  const A = curAnalysis(); const strip = document.getElementById('vstrip'); if (!strip) return;
  strip.replaceChildren(...Array.from({length: S.cur.n_slices}, (_, i) => {
    let cls = 's-na', title = 'нет анализа';
    if (A) { const s = A.result.slices[i]; if (!s.informative) { cls = 's-na'; title = s.reason || 'не информативен'; } else if (s.positive) { cls = 's-pos'; title = 'признак: ' + s.confirmed_corners.join(', '); } else if (s.raw_positive) { cls = 's-raw'; title = 'есть, но < N подряд'; } else { cls = 's-neg'; title = 'признаков нет'; } }
    else cls = '';
    const lab = S.docLabels[String(i)];
    return h('button', {class: cls + (i === S.idx ? ' cur' : ''), title, onclick: () => gotoSlice(i)}, i + 1, lab !== undefined ? h('span', {class: 'dot', style: 'background:' + (lab ? '#ff3b30' : '#2ecc71')}) : null);
  }));
}

async function gotoSlice(i) {
  i = Math.max(0, Math.min(S.cur.n_slices - 1, i)); if (i === S.idx) return;
  if (S.ann.dirty) await saveAnn();
  S.idx = i; const sl = document.getElementById('vslider'); if (sl) sl.value = i;
  S.ann.canv = {}; await loadSlice(); renderStrip(); renderSliceInfo();
}
let _wt = null;
function refreshImg() { clearTimeout(_wt); _wt = setTimeout(loadSlice, 120); }
function loadSlice() {
  return new Promise(res => {
    const img = new Image();
    img.onload = async () => { S.img = img; if (S.mode === 'annot') await loadAnn(); draw(); res(); };
    img.src = `/api/series/${S.cur.id}/slice/${S.idx}.png?lo=${S.lo}&hi=${S.hi}`;
  });
}

function poly(ctx, pts, close) { ctx.beginPath(); pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); if (close) ctx.closePath(); ctx.stroke(); }
function draw() {
  const ctx = S.ctx; if (!ctx || !S.img) return; document.getElementById('vnum').textContent = `${S.idx + 1}/${S.cur.n_slices}`;
  ctx.clearRect(0, 0, S.canvas.width, S.canvas.height); ctx.drawImage(S.img, 0, 0);
  const A = curAnalysis();
  if (A && S.mode === 'view') {
    const sl = A.result.slices[S.idx]; ctx.lineWidth = 1.6; ctx.font = '13px sans-serif';
    if (S.ov.discs) { ctx.strokeStyle = 'rgba(80,160,255,.9)'; (sl.discs || []).forEach(q => poly(ctx, q, true)); }
    (sl.vertebrae || []).forEach(v => {
      if (S.ov.vert) { ctx.strokeStyle = v.extrapolated ? '#f1c40f' : '#2ecc71'; ctx.setLineDash(v.extrapolated ? [5, 4] : []); poly(ctx, v.quad, true); ctx.setLineDash([]); }
      if (S.ov.labels && v.label) { const x = Math.min(...v.quad.map(p => p[0])) - 34, y = v.quad.reduce((a, p) => a + p[1], 0) / 4; ctx.fillStyle = '#7fe0ff'; ctx.fillText(v.label, x, y + 4); }
      Object.entries(v.corners || {}).forEach(([k, c]) => {
        if (S.ov.corners) { ctx.strokeStyle = c.positive ? '#ff3b30' : 'rgba(180,180,180,.45)'; ctx.lineWidth = c.positive ? 1.6 : 0.8; poly(ctx, c.roi, true); ctx.lineWidth = 1.6; }
        if (S.ov.lesions && c.contour && c.positive) { ctx.strokeStyle = '#ff3b30'; ctx.fillStyle = 'rgba(255,59,48,.35)'; ctx.beginPath(); c.contour.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      });
    });
  }
  if (S.mode === 'annot') { ctx.globalAlpha = .5; for (const c of Object.keys(CLS)) if (S.ann.canv[c]) ctx.drawImage(S.ann.canv[c], 0, 0); ctx.globalAlpha = 1; }
}

/* ---------- панель справа ---------- */
function renderPanel() {
  const p = document.getElementById('vpanel'); if (!p) return;
  const st = S.study, A = curAnalysis(), act = activeAnalysis();
  const head = h('div', {class: 'card'}, h('div', {}, h('b', {}, REGION_RU[st.region] || st.region), ' · ', fmt(st.study_date)), h('div', {class: 'small mut'}, fmt(st.device_key)),
    h('label', {style: 'margin-top:8px'}, 'Серия'), h('select', {onchange: e => selectSeries(+e.target.value)}, ...S.series.map(s => h('option', {value: s.id, selected: s.id === S.cur.id}, `${s.weighting} · ${s.description} · ${s.plane} · ${s.n_slices} ср.`))));
  const P = S.params; const pf = {};
  const inp = (k, t, step) => { pf[k] = h('input', {type: 'number', step, value: P[k]}); return h('div', {}, h('label', {}, t), pf[k]); };
  const cons = h('select', {}, ...[1, 2, 3].map(n => h('option', {value: n, selected: P.min_consecutive_slices === n}, n === 1 ? 'на одном срезе' : `на ${n} подряд`)));
  const t1 = h('input', {type: 'checkbox', checked: true, style: 'width:auto'});
  const runBtn = h('button', {class: 'pri', onclick: async () => {
    runBtn.disabled = true; runBtn.textContent = 'Анализ…';
    try {
      const params = {min_consecutive_slices: +cons.value}; for (const k in pf) params[k] = Number(pf[k].value);
      const r = await api('POST', `/api/studies/${S.sid}/analyze`, {params, with_t1: t1.checked});
      const l = await api('GET', '/api/studies/' + S.sid); S.analysesList = l.analyses; S.an = {};
      for (const [m, id] of Object.entries(r.analysis_ids)) { const a = await api('GET', '/api/analyses/' + id); S.an[a.series_id] = a; }
      toast('Анализ выполнен за ' + r.result.series.seconds + ' с'); S.docPos = null; S.docLabels = {};
      const sid = r.result.series.id; if (S.cur.id !== sid) { await selectSeries(sid); } else { render(); draw(); }
    } catch (e) { toast(e.message, true); runBtn.disabled = false; runBtn.textContent = 'Анализировать'; }
  }}, A ? 'Пересчитать' : 'Анализировать');
  const run = S.study.region === 'sij' ? h('div', {class: 'card'}, h('b', {}, 'Модуль КПС'), h('p', {class: 'small mut'}, 'Анализ крестцово-подвздошных суставов в разработке (планируется объединение модулей). Сейчас доступны просмотр, разметка и ведение регистра.'))
    : h('div', {class: 'card'}, h('h2', {}, 'Анализ STIR (активное воспаление)'),
      h('div', {class: 'grid'}, h('div', {}, h('label', {}, 'Правило по срезам'), cons), inp('disc_threshold', 'Порог диска', 0.01), inp('lesion_rel_gain', 'Яркость угла ≥ ×центра', 0.05), inp('min_lesion_area_mm2', 'Мин. площадь, мм²', 0.5), inp('corner_size_mm', 'Угловая зона, мм', 0.5)),
      h('label', {style: 'display:flex;gap:6px;align-items:center;margin-top:8px'}, t1, 'дополнительно Т1 (экспериментально: хронические изменения)'),
      h('div', {style: 'margin-top:10px'}, runBtn));
  const res = h('div', {class: 'card', id: 'vres'}); const sliceInfo = h('div', {id: 'vslice', class: 'small'});
  p.replaceChildren(head, run, res, h('div', {class: 'card'}, sliceInfo), verdictCard(act), S.mode === 'annot' ? annCard() : null,
    h('div', {class: 'card'}, h('div', {class: 'row'}, h('button', {class: S.mode === 'annot' ? 'pri' : '', onclick: toggleAnnot}, S.mode === 'annot' ? 'Выйти из режима разметки' : 'Режим разметки (обучающая выборка)'),
      h('span', {class: 'small mut'}, `размечено срезов: ${Object.keys(S.ann.existing).length}`))));
  renderResult(); renderSliceInfo();
}

function renderResult() {
  const box = document.getElementById('vres'); if (!box) return; const A = curAnalysis();
  if (!A) { box.replaceChildren(h('h2', {}, 'Результат'), h('div', {class: 'mut'}, S.cur.plane === 'sagittal' ? 'Анализ для этой серии ещё не запускался.' : 'Анализ выполняется на сагиттальных сериях.')); return; }
  const r = A.result.study;
  box.replaceChildren(h('h2', {}, A.mode === 'chronic' ? 'Т1 (экспериментально)' : 'Результат алгоритма'),
    h('div', {class: 'concl ' + (r.positive ? 'pos' : 'neg')}, r.conclusion),
    h('div', {class: 'small mut', style: 'margin:6px 0'}, `Информативных срезов: ${r.n_informative} из ${A.result.slices.length}. Версия: ${A.result.version}`),
    r.findings.length ? h('table', {}, h('thead', {}, h('tr', {}, ...['Позвонок', 'Угол', 'Срезы', 'мм²', 'контраст'].map(t => h('th', {}, t)))),
      h('tbody', {}, ...r.findings.map(f => h('tr', {class: 'click', onclick: () => gotoSlice(f.slices[0]), title: 'перейти к срезу'}, h('td', {}, f.level), h('td', {}, CORNER_RU[f.corner]), h('td', {}, f.slices.map(i => i + 1).join(', ')), h('td', {}, f.max_area_mm2), h('td', {}, '×' + f.max_contrast))))) : null);
}
function renderSliceInfo() {
  const box = document.getElementById('vslice'); if (!box) return; const A = curAnalysis();
  const lab = S.docLabels[String(S.idx)];
  const mark = h('div', {class: 'chips'}, h('span', {class: 'mut'}, 'Ваша отметка среза: '),
    ...[[1, 'есть воспаление'], [0, 'нет'], [undefined, 'снять']].map(([v, t]) => h('button', {class: lab === v ? 'on' : '', onclick: () => { if (v === undefined) delete S.docLabels[String(S.idx)]; else S.docLabels[String(S.idx)] = v; renderStrip(); renderSliceInfo(); }}, t)));
  if (!A) { box.replaceChildren(h('b', {}, `Срез ${S.idx + 1}`), mark); return; }
  const s = A.result.slices[S.idx];
  box.replaceChildren(h('b', {}, `Срез ${S.idx + 1}: `), s.informative ? (s.positive ? badge(true, 'признак подтверждён') : s.raw_positive ? h('span', {class: 'badge warn'}, 'есть, правило не выполнено') : badge(false, '', 'признаков нет')) : h('span', {class: 'badge mut'}, 'неинформативен'),
    h('div', {class: 'mut'}, s.informative ? `Позвонков: ${s.n_vertebrae}. Сработавшие углы: ${(s.positive_corners_raw || []).join(', ') || '—'}` : s.reason), mark);
}
function verdictCard(act) {
  const radio = (v, t) => h('label', {style: 'display:flex;gap:6px;align-items:center;color:var(--ink);font-size:14px'}, h('input', {type: 'radio', name: 'dv', style: 'width:auto', checked: S.docPos === v, onchange: () => S.docPos = v}), t);
  const cm = h('textarea', {placeholder: 'Комментарий врача (необязательно)'}, act && act.verdict ? act.verdict.comment || '' : '');
  return h('div', {class: 'card'}, h('h2', {}, 'Заключение врача'), act ? [radio(true, 'Активное воспаление есть'), radio(false, 'Активного воспаления нет'), radio(null, 'Не могу определить'), cm,
    h('div', {style: 'margin-top:8px'}, h('button', {class: 'pri', onclick: async () => {
      await api('POST', `/api/analyses/${act.id}/verdict`, {positive: S.docPos, slice_labels: S.docLabels, comment: cm.value}); toast('Заключение сохранено – используется для оценки качества алгоритма');
    }}, 'Сохранить заключение')), h('p', {class: 'small mut'}, 'Ваши отметки по срезам (кнопки под полосой срезов) тоже сохраняются: по ним считаются чувствительность и специфичность.')]
    : h('div', {class: 'mut small'}, 'Сначала запустите анализ STIR.'));
}

/* ---------- разметка ---------- */
function annCard() {
  const A = S.ann;
  return h('div', {class: 'card'}, h('h2', {}, 'Разметка среза ' + (S.idx + 1)),
    h('div', {class: 'chips'}, ...Object.entries(CLS).map(([k, c]) => h('button', {class: A.cls === k && !A.erase ? 'on' : '', style: `border-left:6px solid ${c.color}`, onclick: () => { A.cls = k; A.erase = false; renderPanel(); }}, c.ru)),
      h('button', {class: A.erase ? 'on' : '', onclick: () => { A.erase = !A.erase; renderPanel(); }}, 'Ластик')),
    h('label', {style: 'margin-top:8px'}, 'Размер кисти: ' + A.brush), h('input', {type: 'range', min: 1, max: 40, value: A.brush, oninput: e => { A.brush = +e.target.value; e.target.previousSibling.textContent = 'Размер кисти: ' + A.brush; }}),
    h('div', {class: 'row', style: 'margin-top:8px'}, h('button', {onclick: prefill}, 'Предразметка по алгоритму'), h('button', {onclick: () => { clearCls(); }}, 'Очистить класс'), h('button', {class: 'pri', onclick: async () => { await saveAnn(true); }}, 'Сохранить срез')),
    h('p', {class: 'small mut'}, 'Рисуйте мышью/пальцем на снимке. Классы соответствуют обучающей выборке (тела, диски, очаги). Сохранённая разметка попадает в «Статистика → Скачать датасет».'));
}
function toggleAnnot() { S.mode = S.mode === 'annot' ? 'view' : 'annot'; S.ann.canv = {}; S.canvas.style.cursor = S.mode === 'annot' ? 'crosshair' : 'default'; renderPanel(); loadSlice(); }
function mkCanvas() { const c = document.createElement('canvas'); c.width = S.cur.meta.cols; c.height = S.cur.meta.rows; return c; }
function recolor(canvas, cls, srcImg, byAlpha) {
  const t = mkCanvas(), tc = t.getContext('2d'); tc.drawImage(srcImg, 0, 0, t.width, t.height);
  const id = tc.getImageData(0, 0, t.width, t.height), d = id.data, col = CLS[cls].color, r = parseInt(col.slice(1, 3), 16), g = parseInt(col.slice(3, 5), 16), b = parseInt(col.slice(5, 7), 16);
  for (let i = 0; i < d.length; i += 4) { const on = byAlpha ? d[i + 3] > 127 : d[i] > 127; d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = on ? 255 : 0; }
  canvas.getContext('2d').putImageData(id, 0, 0);
}
function fetchImg(url) { return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = url; }); }
async function loadAnn() {
  const ex = S.ann.existing[String(S.idx)] || [];
  for (const c of Object.keys(CLS)) {
    if (!S.ann.canv[c]) S.ann.canv[c] = mkCanvas();
    if (ex.includes(c)) { const im = await fetchImg(`/api/series/${S.cur.id}/annotations/${S.idx}/${c}.png?t=${Date.now()}`); if (im) recolor(S.ann.canv[c], c, im, false); }
  }
}
function pos(e) { const r = S.canvas.getBoundingClientRect(); return [(e.clientX - r.left) * S.canvas.width / r.width, (e.clientY - r.top) * S.canvas.height / r.height]; }
function stroke(a, b) {
  const A = S.ann, c = A.canv[A.cls]; if (!c) return; const x = c.getContext('2d');
  x.globalCompositeOperation = A.erase ? 'destination-out' : 'source-over'; x.strokeStyle = x.fillStyle = CLS[A.cls].color; x.lineWidth = A.brush; x.lineCap = x.lineJoin = 'round';
  x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke(); A.dirty = true; draw();
}
function annDown(e) { if (S.mode !== 'annot') return; e.preventDefault(); S.canvas.setPointerCapture(e.pointerId); const p = pos(e); S.ann.drawing = true; S.ann.last = p; stroke(p, [p[0] + .01, p[1]]); }
function annMove(e) { if (S.mode !== 'annot' || !S.ann.drawing) return; const p = pos(e); stroke(S.ann.last, p); S.ann.last = p; }
function annUp() { if (S.ann) S.ann.drawing = false; }
function clearCls() { const c = S.ann.canv[S.ann.cls]; if (c) { c.getContext('2d').clearRect(0, 0, c.width, c.height); S.ann.dirty = true; draw(); } }
function isEmpty(c) { const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; for (let i = 3; i < d.length; i += 4) if (d[i] > 127) return false; return true; }
async function saveAnn(manual) {
  if (S.mode !== 'annot' && !S.ann.dirty) return;
  const masks = {}; for (const c of Object.keys(CLS)) if (S.ann.canv[c]) masks[c] = isEmpty(S.ann.canv[c]) ? null : S.ann.canv[c].toDataURL('image/png');
  await api('PUT', `/api/series/${S.cur.id}/annotations/${S.idx}`, {masks});
  S.ann.existing = await api('GET', `/api/series/${S.cur.id}/annotations`); S.ann.dirty = false; if (manual) toast('Разметка среза сохранена');
}
async function prefill() {
  const act = Object.values(S.an).find(a => a.series_id === S.cur.id && a.mode === 'active');
  if (!act) return toast('Предразметка возможна после анализа этой серии (режим STIR)', true);
  const r = await api('POST', `/api/series/${S.cur.id}/annotations/${S.idx}/prefill`, {analysis_id: act.id});
  for (const c of Object.keys(CLS)) { if (!S.ann.canv[c]) S.ann.canv[c] = mkCanvas(); const im = await fetchImg(r.masks[c]); S.ann.canv[c].getContext('2d').clearRect(0, 0, 9999, 9999); if (im) recolor(S.ann.canv[c], c, im, true); }
  S.ann.dirty = true; draw(); toast('Предразметка добавлена – поправьте и сохраните');
}
