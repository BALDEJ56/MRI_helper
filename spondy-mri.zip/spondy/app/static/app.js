/* Spondy-MRI: общий каркас, реестр пациентов, карточка пациента, статистика, настройки */
const $app = () => document.getElementById('app');
let ME = null;
const CORNER_RU = {AS: 'передне-верхний', PS: 'задне-верхний', AI: 'передне-нижний', PI: 'задне-нижний'};
const REGION_RU = {lumbar: 'поясничный отдел', sij: 'крестцово-подвздошные суставы (КПС)'};

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'class') e.className = v;
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat(9)) if (k != null && k !== false) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
}
function toast(msg, bad) {
  const d = h('div', {class: bad ? 'e' : ''}, msg); document.getElementById('toast').append(d);
  setTimeout(() => d.remove(), bad ? 7000 : 3500);
}
async function api(method, url, body, raw) {
  const o = {method, headers: {'X-Requested-With': 'fetch'}};
  if (body instanceof FormData) o.body = body;
  else if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
  const r = await fetch(url, o);
  if (r.status === 401 && !url.endsWith('/login')) { ME = null; location.hash = '#/login'; throw new Error('Требуется вход'); }
  if (raw) return r;
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error((j && j.error) || ('Ошибка ' + r.status));
  return j;
}
const fmt = (v, d = '–') => (v === null || v === undefined || v === '') ? d : v;
const badge = (pos, yes = 'есть признаки', no = 'нет признаков') =>
  pos === null || pos === undefined ? h('span', {class: 'badge mut'}, '—') : h('span', {class: 'badge ' + (pos ? 'pos' : 'neg')}, pos ? yes : no);

function shell(active, content) {
  const link = (hash, t, key) => h('a', {href: hash, class: active === key ? 'on' : ''}, t);
  $app().replaceChildren(
    h('nav', {}, h('span', {class: 'brand'}, 'Spondy-MRI'), link('#/registry', 'Реестр пациентов', 'registry'),
      link('#/stats', 'Статистика и база', 'stats'), link('#/settings', 'Настройки', 'settings'), h('span', {class: 'sp'}),
      h('span', {class: 'mut small'}, ME ? ME.user + ' (' + ME.role + ')' : ''),
      h('button', {onclick: async () => { await api('POST', '/api/logout'); ME = null; location.hash = '#/login'; }}, 'Выйти')),
    h('main', {}, content),
    h('footer', {}, 'Вспомогательное ПО для поддержки принятия решения; не является диагнозом и не заменяет врача. Данные обезличены (код пациента вместо ФИО).'));
}

/* ---------- маршрутизация ---------- */
async function boot() {
  window.addEventListener('hashchange', route);
  try { ME = await api('GET', '/api/me'); } catch (e) { ME = null; }
  if (!ME) location.hash = '#/login';
  else if (!location.hash || location.hash === '#/login') location.hash = '#/registry';
  route();
}
async function route() {
  const hash = location.hash || '#/registry';
  try {
    if (!ME && hash !== '#/login') { try { ME = await api('GET', '/api/me'); } catch (e) {} }
    if (!ME) return viewLogin();
    let m;
    if (hash === '#/login') { location.hash = '#/registry'; return; }
    if (hash === '#/registry') return await viewRegistry();
    if ((m = hash.match(/^#\/patient\/(\d+)/))) return await viewPatient(+m[1]);
    if ((m = hash.match(/^#\/study\/(\d+)/))) return await viewStudy(+m[1]);
    if (hash === '#/stats') return await viewStats();
    if (hash === '#/settings') return await viewSettings();
    location.hash = '#/registry';
  } catch (e) { toast(e.message, true); }
}

/* ---------- вход ---------- */
function viewLogin() {
  const u = h('input', {type: 'text', autocomplete: 'username'}), p = h('input', {type: 'password', autocomplete: 'current-password'});
  const go = async () => {
    try { ME = await api('POST', '/api/login', {username: u.value, password: p.value}); location.hash = '#/registry'; route(); }
    catch (e) { toast(e.message, true); }
  };
  p.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  $app().replaceChildren(h('div', {class: 'card login'}, h('h1', {}, 'Spondy-MRI'),
    h('p', {class: 'mut'}, 'Анализ МРТ позвоночника при спондилоартрите и регистр пациентов'),
    h('label', {}, 'Логин'), u, h('label', {style: 'margin-top:8px'}, 'Пароль'), p,
    h('button', {class: 'pri', style: 'margin-top:12px;width:100%', onclick: go}, 'Войти')));
}

/* ---------- реестр ---------- */
async function viewRegistry() {
  const q = h('input', {placeholder: 'Поиск: код, диагноз, заметки…'});
  const tb = h('tbody'); const info = h('div', {class: 'mut small'});
  const prog = h('div');
  const load = async () => {
    const rows = await api('GET', '/api/patients?q=' + encodeURIComponent(q.value));
    info.textContent = 'Найдено пациентов: ' + rows.length;
    tb.replaceChildren(...rows.map(p => h('tr', {class: 'click', onclick: () => location.hash = '#/patient/' + p.id},
      h('td', {}, h('b', {}, p.code)), h('td', {}, fmt(p.sex), p.birth_year ? ' / ' + p.birth_year : ''), h('td', {}, fmt(p.diagnosis)),
      h('td', {}, p.n_studies), h('td', {class: 'small'}, fmt(p.devices)), h('td', {class: 'small'}, (p.regions || '').split(',').filter(Boolean).map(r => REGION_RU[r] || r).join(', ') || '–'),
      h('td', {}, badge(p.ai_positive === null ? null : !!p.ai_positive)), h('td', {}, badge(p.doctor_positive === null ? null : !!p.doctor_positive)))));
    const st = await api('GET', '/api/stats');
    prog.replaceChildren(h('div', {class: 'small mut'}, `База для обучения: пациентов с разметкой ${st.annotated_patients} из ${st.targets.patients} (план), размеченных срезов ${st.annotated_slices}`),
      h('div', {class: 'bar'}, h('i', {style: `width:${Math.min(100, 100 * st.annotated_patients / st.targets.patients)}%`})));
  };
  q.addEventListener('input', () => { clearTimeout(q._t); q._t = setTimeout(load, 250); });
  shell('registry', [
    h('div', {class: 'row'}, h('h1', {class: 'grow'}, 'Интерактивный регистр пациентов'),
      h('button', {class: 'pri', onclick: async () => { const r = await api('POST', '/api/patients', {}); location.hash = '#/patient/' + r.id; }}, '+ Новый пациент'),
      h('a', {class: 'btn', href: '/api/export/registry.csv'}, 'Экспорт CSV')),
    h('div', {class: 'card'}, h('div', {class: 'row'}, h('div', {class: 'grow'}, q), info), h('div', {style: 'margin-top:10px'}, prog)),
    h('div', {class: 'card', style: 'overflow:auto'}, h('table', {}, h('thead', {}, h('tr', {}, ...['Код', 'Пол / г.р.', 'Диагноз', 'Исслед.', 'Аппараты', 'Область', 'ИИ', 'Врач'].map(t => h('th', {}, t)))), tb))]);
  await load();
}

/* ---------- карточка пациента ---------- */
async function viewPatient(pid) {
  const d = await api('GET', '/api/patients/' + pid); const p = d.patient;
  const f = {};
  const fld = (key, label, el) => { f[key] = el; return h('div', {}, h('label', {}, label), el); };
  const sel = (opts, val) => { const s = h('select', {}, ...opts.map(([v, t]) => h('option', {value: v}, t))); s.value = val == null ? '' : String(val); return s; };
  const num = (v, step) => h('input', {type: 'number', step: step || 'any', value: v == null ? '' : v});
  const grid = h('div', {class: 'grid'},
    fld('sex', 'Пол', sel([['', '—'], ['F', 'Женский'], ['M', 'Мужской']], p.sex)),
    fld('birth_year', 'Год рождения', num(p.birth_year, 1)),
    fld('axspa', 'Диагноз аксСпА подтверждён', sel([['', '—'], ['1', 'да'], ['0', 'нет']], p.axspa)),
    fld('hla_b27', 'HLA-B27', sel([['', '—'], ['1', 'положит.'], ['0', 'отрицат.']], p.hla_b27)),
    fld('crp', 'СРБ, мг/л', num(p.crp)), fld('basdai', 'BASDAI', num(p.basdai)), fld('asdas', 'ASDAS', num(p.asdas)),
    fld('diagnosis', 'Диагноз / формулировка', h('input', {value: p.diagnosis || ''})),
    fld('therapy', 'Терапия (ГИБП и др.)', h('input', {value: p.therapy || ''})));
  const notes = h('textarea', {}, p.notes || '');
  const save = async () => {
    const body = {notes: notes.value};
    for (const [k, el] of Object.entries(f)) body[k] = ['axspa', 'hla_b27', 'birth_year'].includes(k) && el.value !== '' ? Number(el.value) : (['crp', 'basdai', 'asdas'].includes(k) && el.value !== '' ? Number(el.value) : el.value);
    await api('PUT', '/api/patients/' + pid, body); toast('Сохранено');
  };
  const files = h('input', {type: 'file', multiple: true, accept: '.dcm,.zip,application/dicom,application/zip,*/*'});
  const folder = h('input', {type: 'file', multiple: true, webkitdirectory: true});
  const region = h('select', {}, h('option', {value: ''}, 'определить автоматически'), h('option', {value: 'lumbar'}, 'поясничный отдел'), h('option', {value: 'sij'}, 'КПС (крестцово-подвздошные суставы)'));
  const msg = h('div', {class: 'small mut'});
  const up = async () => {
    const list = [...files.files, ...folder.files]; if (!list.length) return toast('Выберите DICOM-файлы, папку или zip', true);
    const fd = new FormData(); list.forEach(x => fd.append('files', x, x.name)); fd.append('region', region.value);
    msg.textContent = `Загрузка ${list.length} файл(ов)… это может занять до минуты`;
    try {
      const r = await api('POST', `/api/patients/${pid}/upload`, fd);
      toast(`Добавлено серий: ${r.added.length}` + (r.skipped.length ? `, пропущено: ${r.skipped.length}` : '')); viewPatient(pid);
    } catch (e) { msg.textContent = ''; toast(e.message, true); }
  };
  const studies = d.studies.map(s => h('tr', {class: 'click', onclick: () => location.hash = '#/study/' + s.id},
    h('td', {}, fmt(s.study_date)), h('td', {class: 'small'}, fmt(s.device_key)), h('td', {}, REGION_RU[s.region] || s.region),
    h('td', {class: 'small'}, s.series.map(x => h('span', {class: 'badge mut'}, `${x.weighting} ${x.plane === 'sagittal' ? 'сагитт.' : x.plane === 'axial' ? 'аксиал.' : 'корон.'} ·${x.n_slices}`))),
    h('td', {}, s.analysis ? badge(!!s.analysis.positive) : h('span', {class: 'badge mut'}, 'не анализировалось')), h('td', {}, s.verdict ? badge(!!s.verdict.positive) : '—')));
  shell('registry', [
    h('div', {class: 'row'}, h('h1', {class: 'grow'}, 'Пациент ', p.code), h('a', {href: '#/registry'}, '← к реестру'),
      ME.role === 'admin' ? h('button', {class: 'dng', onclick: async () => { if (confirm('Удалить пациента и все его данные?')) { await api('DELETE', '/api/patients/' + pid); location.hash = '#/registry'; } }}, 'Удалить') : null),
    h('div', {class: 'card'}, h('h2', {}, 'Клинические данные (обезличенные)'), grid, h('div', {style: 'margin-top:10px'}, h('label', {}, 'Заметки'), notes),
      h('div', {style: 'margin-top:10px'}, h('button', {class: 'pri', onclick: save}, 'Сохранить'))),
    h('div', {class: 'card'}, h('h2', {}, 'Загрузка МРТ (DICOM)'),
      h('div', {class: 'row'}, h('div', {class: 'grow'}, h('label', {}, 'Файлы DICOM или zip'), files), h('div', {class: 'grow'}, h('label', {}, 'или целая папка исследования'), folder),
        h('div', {}, h('label', {}, 'Область'), region), h('button', {class: 'pri', onclick: up}, 'Загрузить')), msg,
      h('p', {class: 'small mut'}, 'Принимаются снимки с любого аппарата (Philips Multiva, GE Signa Explorer и др.). Имя, ID и дата рождения из DICOM не сохраняются.')),
    h('div', {class: 'card', style: 'overflow:auto'}, h('h2', {}, 'Исследования'),
      d.studies.length ? h('table', {}, h('thead', {}, h('tr', {}, ...['Дата', 'Аппарат', 'Область', 'Серии', 'ИИ', 'Врач'].map(t => h('th', {}, t)))), h('tbody', {}, ...studies)) : h('div', {class: 'mut'}, 'Исследований пока нет.'))]);
}

/* ---------- статистика и база для обучения ---------- */
async function viewStats() {
  const s = await api('GET', '/api/stats');
  const metricRow = (name, m) => m ? h('tr', {}, h('td', {}, name), h('td', {}, m.n), h('td', {}, fmt(m.sensitivity)), h('td', {}, fmt(m.specificity)), h('td', {}, fmt(m.f1)), h('td', {}, fmt(m.kappa)), h('td', {class: 'small'}, `TP ${m.tp} · FP ${m.fp} · FN ${m.fn} · TN ${m.tn}`)) : null;
  const rowsM = [metricRow('Исследование в целом', s.agreement_study), metricRow('Отдельные срезы', s.agreement_slices),
    ...Object.entries(s.agreement_by_device || {}).map(([k, v]) => metricRow('Аппарат: ' + k, v))].filter(Boolean);
  const pct = (a, b) => Math.min(100, 100 * a / b);
  shell('stats', [
    h('h1', {}, 'Статистика и база для обучения'),
    h('div', {class: 'grid'}, ...[['Пациентов', s.patients], ['Исследований', s.studies], ['Серий', s.series], ['Анализов ИИ', s.analyses], ['Заключений врача', s.verdicts]].map(([t, v]) => h('div', {class: 'card'}, h('div', {class: 'mut small'}, t), h('div', {style: 'font-size:26px;font-weight:700'}, v)))),
    h('div', {class: 'card'}, h('h2', {}, 'Сбор размеченной базы'),
      h('div', {}, `Пациентов с разметкой: ${s.annotated_patients} / ${s.targets.patients} (на первом этапе – 15, в перспективе – 40)`), h('div', {class: 'bar'}, h('i', {style: `width:${pct(s.annotated_patients, s.targets.patients)}%`})),
      h('div', {style: 'margin-top:8px'}, `Размеченных срезов: ${s.annotated_slices} / ${s.targets.patients * s.targets.slices_per_patient} (≈ ${s.targets.slices_per_patient} срезов на пациента)`), h('div', {class: 'bar'}, h('i', {style: `width:${pct(s.annotated_slices, s.targets.patients * s.targets.slices_per_patient)}%`})),
      h('div', {style: 'margin-top:10px'}, h('a', {class: 'btn pri', href: '/api/export/dataset.zip'}, 'Скачать датасет (изображения + маски + manifest, разбиение 70/15/15 по пациентам)'))),
    h('div', {class: 'card'}, h('h2', {}, 'Согласие алгоритма с заключением врача'),
      rowsM.length ? h('table', {}, h('thead', {}, h('tr', {}, ...['Уровень', 'N', 'Чувствит.', 'Специфичн.', 'F1', 'κ Коэна', 'Матрица'].map(t => h('th', {}, t)))), h('tbody', {}, ...rowsM)) : h('div', {class: 'mut'}, 'Пока нет заключений врача: откройте исследование, нажмите «Анализировать» и сохраните своё заключение.'),
      h('p', {class: 'small'}, `Целевые значения из ВКР: чувствительность ≥ ${s.targets.quality.sensitivity}, специфичность ≥ ${s.targets.quality.specificity}.`),
      s.reader_agreement ? h('p', {class: 'small'}, `Согласие между читателями (разные врачи/студенты по одним исследованиям): N=${s.reader_agreement.n}, κ=${fmt(s.reader_agreement.kappa)}, совпадение ${fmt(s.reader_agreement.accuracy)}.`) : h('p', {class: 'small mut'}, 'Согласие между читателями появится, когда два и более пользователей оставят заключения по одним исследованиям.'),
      h('p', {class: 'small mut'}, 'Метрики считаются относительно заключений врача, накопленных в системе. При малом N (меньше нескольких десятков исследований) значения ориентировочные, доверительные интервалы широкие.')),
    h('div', {class: 'grid'},
      h('div', {class: 'card'}, h('h2', {}, 'По аппаратам'), ...s.by_device.map(x => h('div', {}, x.device, ': ', h('b', {}, x.n)))),
      h('div', {class: 'card'}, h('h2', {}, 'По областям'), ...s.by_region.map(x => h('div', {}, REGION_RU[x.region] || x.region, ': ', h('b', {}, x.n)))),
      h('div', {class: 'card'}, h('h2', {}, 'Результат ИИ'), h('div', {}, 'Признаки есть: ', h('b', {}, s.ai_positive_studies)), h('div', {}, 'Признаков нет: ', h('b', {}, s.ai_negative_studies))))]);
}

/* ---------- настройки ---------- */
async function viewSettings() {
  const P = await api('GET', '/api/settings/params'); const admin = ME.role === 'admin';
  const spec = [
    ['min_consecutive_slices', 'Очаг должен быть на N подряд срезах (1–3)', 1], ['min_vertebrae_per_slice', 'Мин. число тел позвонков на информативном срезе', 1],
    ['min_body_width_mm', 'Мин. ширина тела позвонка, мм (отсев боковых срезов)', 1], ['disc_threshold', 'Порог яркости диска (доля от p99.7)', 0.01],
    ['corner_size_mm', 'Размер угловой зоны, мм', 0.5], ['corner_margin_mm', 'Отступ от кортикала/пластинки, мм', 0.1], ['corner_margin_posterior_mm', 'Отступ у заднего края, мм', 0.1],
    ['lesion_rel_gain', 'Порог: во сколько раз ярче центра тела', 0.05], ['lesion_k_sigma', 'Порог: центр + k·σ шума', 0.5], ['min_lesion_area_mm2', 'Мин. площадь очага, мм²', 0.5], ['max_csf_level', 'Макс. яркость (выше – считается ликвором)', 0.05]];
  const f = {};
  const grid = h('div', {class: 'grid'}, ...spec.map(([k, t, st]) => { f[k] = h('input', {type: 'number', step: st, value: P[k], disabled: !admin}); return h('div', {}, h('label', {}, t), f[k]); }));
  const lv = h('input', {value: P.levels.join(', '), disabled: !admin});
  const body = [h('h1', {}, 'Настройки'),
    h('div', {class: 'card'}, h('h2', {}, 'Параметры алгоритма (по умолчанию для всех анализов)'), grid,
      h('div', {style: 'margin-top:10px'}, h('label', {}, 'Позвонки сверху вниз (подпись стека идёт от нижнего позвонка)'), lv),
      admin ? h('div', {style: 'margin-top:10px'}, h('button', {class: 'pri', onclick: async () => {
        const b = {...P}; for (const [k] of spec) b[k] = Number(f[k].value); b.levels = lv.value.split(',').map(x => x.trim()).filter(Boolean);
        await api('PUT', '/api/settings/params', b); toast('Параметры сохранены');
      }}, 'Сохранить')) : h('p', {class: 'mut small'}, 'Менять параметры может только администратор.'))];
  if (admin) {
    const nu = h('input', {placeholder: 'логин'}), np = h('input', {type: 'password', placeholder: 'пароль ≥ 8 символов'}), nr = h('select', {}, h('option', {value: 'doctor'}, 'врач'), h('option', {value: 'admin'}, 'администратор'));
    const logBox = h('div', {class: 'small'});
    body.push(h('div', {class: 'card'}, h('h2', {}, 'Пользователи'), h('div', {class: 'row'}, h('div', {}, nu), h('div', {}, np), h('div', {}, nr),
      h('button', {onclick: async () => { await api('POST', '/api/users', {username: nu.value, password: np.value, role: nr.value}); toast('Пользователь добавлен'); nu.value = np.value = ''; }}, 'Добавить'))));
    body.push(h('div', {class: 'card'}, h('h2', {}, 'Журнал действий'), h('button', {onclick: async () => {
      const a = await api('GET', '/api/audit'); logBox.replaceChildren(h('table', {}, ...a.map(r => h('tr', {}, h('td', {}, new Date(r.ts * 1000).toLocaleString('ru')), h('td', {}, r.username), h('td', {}, r.action), h('td', {class: 'mut'}, r.detail)))));
    }}, 'Показать последние 300 записей'), logBox));
  }
  shell('settings', body);
}
