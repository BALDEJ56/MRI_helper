import sqlite3, os, json, time
from flask import g, current_app

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pw_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'doctor', created REAL);
CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, sex TEXT, birth_year INTEGER,
  diagnosis TEXT, axspa INTEGER, crp REAL, hla_b27 INTEGER, basdai REAL, asdas REAL, therapy TEXT, notes TEXT,
  created REAL, created_by TEXT);
CREATE TABLE IF NOT EXISTS studies(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  region TEXT NOT NULL DEFAULT 'lumbar', study_date TEXT, device_key TEXT, study_uid TEXT, note TEXT, created REAL);
CREATE TABLE IF NOT EXISTS series(id INTEGER PRIMARY KEY, study_id INTEGER NOT NULL REFERENCES studies(id) ON DELETE CASCADE,
  series_uid TEXT UNIQUE, description TEXT, plane TEXT, weighting TEXT, n_slices INTEGER, meta_json TEXT, vol_file TEXT);
CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY, study_id INTEGER NOT NULL REFERENCES studies(id) ON DELETE CASCADE,
  series_id INTEGER NOT NULL REFERENCES series(id) ON DELETE CASCADE, mode TEXT, params_json TEXT, result_json TEXT,
  positive INTEGER, version TEXT, created REAL, created_by TEXT);
CREATE TABLE IF NOT EXISTS verdicts(id INTEGER PRIMARY KEY, analysis_id INTEGER NOT NULL REFERENCES analyses(id) ON DELETE CASCADE,
  doctor TEXT, positive INTEGER, slice_labels_json TEXT, comment TEXT, created REAL);
CREATE TABLE IF NOT EXISTS annotations(id INTEGER PRIMARY KEY, series_id INTEGER NOT NULL REFERENCES series(id) ON DELETE CASCADE,
  slice_index INTEGER NOT NULL, cls TEXT NOT NULL, file TEXT, author TEXT, updated REAL, UNIQUE(series_id, slice_index, cls));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts REAL, username TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    os.makedirs(os.path.dirname(app.config["DB_PATH"]), exist_ok=True)
    con = sqlite3.connect(app.config["DB_PATH"])
    con.executescript(SCHEMA)
    con.commit(); con.close()
    app.teardown_appcontext(close_db)


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def audit(user, action, detail=""):
    db = get_db()
    db.execute("INSERT INTO audit(ts,username,action,detail) VALUES(?,?,?,?)", (time.time(), user, action, str(detail)[:500]))
    db.commit()
