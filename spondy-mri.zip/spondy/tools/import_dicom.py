"""Массовая загрузка DICOM в реестр:  python tools/import_dicom.py --patient P-0001 [--region lumbar|sij] ПУТЬ [ПУТЬ ...]
ПУТЬ – папка, zip или файлы. Если пациента с таким кодом нет – он создаётся."""
import argparse, os, glob
from _common import data_dir
from app import create_app

ap = argparse.ArgumentParser()
ap.add_argument("--data"); ap.add_argument("--patient", required=True); ap.add_argument("--region", default="")
ap.add_argument("paths", nargs="+")
a = ap.parse_args()
app = create_app(data_dir(a.data))
c = app.test_client()
with c.session_transaction() as s:
    s["user"], s["role"] = "import-cli", "admin"
H = {"X-Requested-With": "fetch"}
pid = next((p["id"] for p in c.get("/api/patients?q=" + a.patient).get_json() if p["code"] == a.patient), None)
if pid is None:
    pid = c.post("/api/patients", json={"code": a.patient}, headers=H).get_json()["id"]
files = []
for p in a.paths:
    files += [f for f in glob.glob(os.path.join(p, "**", "*"), recursive=True) if os.path.isfile(f)] if os.path.isdir(p) else [p]
data = {"files": [(open(f, "rb"), os.path.basename(f)) for f in files], "region": a.region}
r = c.post(f"/api/patients/{pid}/upload", data=data, content_type="multipart/form-data", headers=H)
print(r.status_code, r.get_json())
