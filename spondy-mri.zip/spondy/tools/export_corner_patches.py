"""Патчи угловых зон 32×32 (ВКР, этап 2) + метки по разметке очагов врача:  python tools/export_corner_patches.py [--data DIR] [--out corner_patches.npz]
Метка угла = 1, если разметка «очаги» врача внутри ROI угла ≥ min_lesion_area_mm2. Для обучения tools/train_corner_clf.py."""
import argparse, json, os
import numpy as np, cv2
from _common import data_dir, connect
from app import storage, exporter
from app.core.config import AnalysisParams
from app.core.preprocess import normalize_volume, smooth
from app.core.lesions import straighten, corner_rois, corner_patch, CORNERS, RES

ap = argparse.ArgumentParser(); ap.add_argument("--data"); ap.add_argument("--out", default="corner_patches.npz"); a = ap.parse_args()
d = data_dir(a.data); con = connect(d); P = AnalysisParams()
X, Y, PAT, DEV, SPLIT = [], [], [], [], []
for s in con.execute("""SELECT DISTINCT an.series_id sid, s.vol_file, s.meta_json, p.code, st.device_key FROM annotations an JOIN series s ON s.id=an.series_id
        JOIN studies st ON st.id=s.study_id JOIN patients p ON p.id=st.patient_id WHERE an.cls='lesion'"""):
    r = con.execute("SELECT result_json FROM analyses WHERE series_id=? AND mode='active' ORDER BY id DESC LIMIT 1", (s["sid"],)).fetchone()
    if not r:
        continue
    res = json.loads(r["result_json"]); meta = json.loads(s["meta_json"]); sp = meta["spacing_mm"]
    n = normalize_volume(storage.load_volume(d + "/volumes", s["vol_file"]))
    for row in con.execute("SELECT slice_index,file FROM annotations WHERE series_id=? AND cls='lesion'", (s["sid"],)):
        i = row["slice_index"]; gt = cv2.imread(os.path.join(d, "annotations", row["file"]), 0) > 127
        g = smooth(n[i], P.smooth_sigma_mm, sp)
        for v in res["slices"][i]["vertebrae"]:
            quad = np.array(v["quad"]); patch, Minv = straighten(g, quad, sp); H_, W_ = patch.shape
            ref = float(np.median(patch[int(.3 * H_):int(.7 * H_)+1, int(.3 * W_):int(.7 * W_)+1]))
            rois = corner_rois(W_, H_, P)
            for k in v["corners"]:
                x0, y0, x1, y1 = rois[k]
                M_ = np.linalg.inv(Minv)   # изображение → патч
                warped = cv2.warpPerspective(gt.astype(np.uint8), M_, (W_, H_), flags=cv2.INTER_NEAREST)
                area = warped[y0:y1, x0:x1].sum() * RES * RES
                X.append(corner_patch(patch, (x0, y0, x1, y1), ref)); Y.append(int(area >= P.min_lesion_area_mm2))
                PAT.append(s["code"]); DEV.append(s["device_key"]); SPLIT.append(exporter.split_of(s["code"]))
np.savez_compressed(a.out, X=np.array(X), y=np.array(Y), patient=np.array(PAT), device=np.array(DEV), split=np.array(SPLIT))
print("патчей:", len(X), "положительных:", int(np.sum(Y)))
