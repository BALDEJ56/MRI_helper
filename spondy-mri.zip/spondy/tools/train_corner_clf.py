"""Классификатор угла 32×32 (ВКР, этап 2: бинарная «активный спондилит есть/нет»).
  python tools/export_corner_patches.py --out corner_patches.npz
  python tools/train_corner_clf.py --patches corner_patches.npz --arch small   # или effb3 (нужен torchvision)
Экспортирует models/corner_clf.onnx (вход [1,1,32,32], выход – вероятность). В среде разработки НЕ запускался (нет torch):
проверьте на малом числе эпох. При дисбалансе классов используется взвешенная BCE; делится по полю split (по пациентам)."""
import argparse, os, numpy as np
import torch, torch.nn as nn, torch.nn.functional as F


def small():
    c = lambda i, o: nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(True), nn.MaxPool2d(2))
    return nn.Sequential(c(1, 16), c(16, 32), c(32, 64), nn.Flatten(), nn.Dropout(.3), nn.Linear(64 * 16, 1))


def effb3():
    from torchvision.models import efficientnet_b3
    m = efficientnet_b3(weights=None); m.features[0][0] = nn.Conv2d(1, 40, 3, 2, 1, bias=False); m.classifier[1] = nn.Linear(m.classifier[1].in_features, 1); return m


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--patches", required=True); ap.add_argument("--arch", default="small"); ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--out", default="models"); a = ap.parse_args(); torch.manual_seed(0)
    d = np.load(a.patches, allow_pickle=True); X, y, sp = d["X"][:, None].astype(np.float32), d["y"].astype(np.float32), d["split"]
    tr, va = sp == "train", sp == "val"
    if va.sum() == 0: va = tr
    net = small() if a.arch == "small" else effb3(); opt = torch.optim.AdamW(net.parameters(), 1e-3, weight_decay=1e-3)
    pos = max(y[tr].sum(), 1); w = torch.tensor((tr.sum() - pos) / pos); Xt, yt = torch.tensor(X[tr]), torch.tensor(y[tr]); best = -1
    for ep in range(a.epochs):
        net.train(); perm = torch.randperm(len(Xt))
        for i in range(0, len(Xt), 64):
            b = perm[i:i + 64]; xb = Xt[b] * torch.empty(len(b), 1, 1, 1).uniform_(.9, 1.1)
            loss = F.binary_cross_entropy_with_logits(net(xb).squeeze(1), yt[b], pos_weight=w); opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad(): p = torch.sigmoid(net(torch.tensor(X[va])).squeeze(1)).numpy()
        yv = y[va]; se = ((p > .5) & (yv > 0)).sum() / max((yv > 0).sum(), 1); spc = ((p <= .5) & (yv == 0)).sum() / max((yv == 0).sum(), 1)
        j = se + spc - 1; print(f"ep{ep} val Se {se:.2f} Sp {spc:.2f}")
        if j > best: best = j; torch.save(net.state_dict(), os.path.join(a.out, "corner_clf.pt"))
    net.load_state_dict(torch.load(os.path.join(a.out, "corner_clf.pt"))); net.eval()
    torch.onnx.export(net, torch.zeros(1, 1, 32, 32), os.path.join(a.out, "corner_clf.onnx"), input_names=["x"], output_names=["y"], opset_version=17)
    print("готово: models/corner_clf.onnx; Youden на val:", round(best, 3))


if __name__ == "__main__":
    main()
