"""Подбор порогов по размеченным врачом срезам (leave-one-patient-out):  python tools/calibrate.py [--data DIR]
Использует отметки врача по срезам (кнопки «есть воспаление / нет» в просмотрщике). Геометрия позвонков считается один раз
на серию, затем перебираются пороги угла. Печатает лучшие параметры и честную оценку LOPO. Результат – рекомендация:
применять вручную (Настройки), после просмотра врачом."""
import argparse, json, itertools
import numpy as np
from _common import data_dir, connect
from app import storage
from app.core.config import AnalysisParams
from app.core.pipeline import analyze_series
from app.core import metrics as M

ap = argparse.ArgumentParser(); ap.add_argument("--data"); ap.add_argument("--fast", action="store_true"); a = ap.parse_args()
d = data_dir(a.data); con = connect(d)
cases = []
for r in con.execute("""SELECT a.series_id, st.patient_id, v.slice_labels_json, s.vol_file, s.meta_json FROM analyses a
    JOIN studies st ON st.id=a.study_id JOIN series s ON s.id=a.series_id
    JOIN verdicts v ON v.id=(SELECT MAX(id) FROM verdicts WHERE analysis_id=a.id) WHERE a.mode='active'"""):
    lab = json.loads(r["slice_labels_json"] or "{}")
    if lab:
        cases.append((r["patient_id"], storage.load_volume(d + "/volumes", r["vol_file"]), json.loads(r["meta_json"])["spacing_mm"], {int(k): v for k, v in lab.items()}))
if len(cases) < 3:
    raise SystemExit("Нужно хотя бы 3 исследования с отметками врача по срезам (лучше 10+).")
grid = list(itertools.product([1.4, 1.8], [3.0], [4.0, 8.0], [12.0])) if a.fast else list(itertools.product([1.4, 1.6, 1.8, 2.0], [2.0, 3.0, 4.0], [3.0, 4.0, 6.0, 8.0], [10.0, 12.0, 15.0]))
base = AnalysisParams(); geo = [analyze_series(v, sp, base) for _, v, sp, _ in cases]
pred = {}
for g in grid:
    P = AnalysisParams(lesion_rel_gain=g[0], lesion_k_sigma=g[1], min_lesion_area_mm2=g[2], corner_size_mm=g[3], min_consecutive_slices=1)
    pred[g] = [analyze_series(v, sp, P, geometry_from=geo[i]) for i, (_, v, sp, _) in enumerate(cases)]


def collect(g, idx):
    yt, yp = [], []
    for i in idx:
        sl = pred[g][i]["slices"]
        for k, lab in cases[i][3].items():
            if k < len(sl) and sl[k]["informative"]:
                yt.append(lab); yp.append(int(sl[k]["raw_positive"]))
    return yt, yp


def score(g, idx):
    yt, yp = collect(g, idx); m = M.classification_metrics(yt, yp)
    return (m["sensitivity"] or 0) + (m["specificity"] or 0) - 1, m


pats = sorted({c[0] for c in cases}); allidx = list(range(len(cases)))
best = max(grid, key=lambda g: score(g, allidx)[0])
print("лучшие параметры (на всех данных):", dict(zip(["lesion_rel_gain", "lesion_k_sigma", "min_lesion_area_mm2", "corner_size_mm"], best)), score(best, allidx)[1])
YT, YP = [], []
for p in pats:
    tr = [i for i in allidx if cases[i][0] != p]; te = [i for i in allidx if cases[i][0] == p]
    if not tr:
        continue
    g = max(grid, key=lambda g: score(g, tr)[0]); yt, yp = collect(g, te); YT += yt; YP += yp
print("честная оценка (leave-one-patient-out):", M.classification_metrics(YT, YP))
