"""Эталонные перцентили для межаппаратной нормализации (Nyul–Udupa) по обучающей выборке, раздельно для аппаратов:
  python tools/learn_landmarks.py [--data DIR]  → models/landmarks.json   (app.core.preprocess.nyul_apply)"""
import argparse, json, os
import numpy as np
from _common import data_dir, connect
from app import storage
from app.core.preprocess import landmarks

ap = argparse.ArgumentParser(); ap.add_argument("--data"); a = ap.parse_args()
d = data_dir(a.data); con = connect(d); acc = {}
for s in con.execute("SELECT s.vol_file, st.device_key FROM series s JOIN studies st ON st.id=s.study_id WHERE s.weighting='STIR' AND s.plane='sagittal'"):
    acc.setdefault(s["device_key"], []).append(landmarks(storage.load_volume(d + "/volumes", s["vol_file"])))
allm = [l for v in acc.values() for l in v]
out = {"standard": np.mean(allm, 0).tolist() if allm else None, "per_device_mean": {k: np.mean(v, 0).tolist() for k, v in acc.items()}}
os.makedirs("models", exist_ok=True); json.dump(out, open("models/landmarks.json", "w"), indent=1); print(out)
