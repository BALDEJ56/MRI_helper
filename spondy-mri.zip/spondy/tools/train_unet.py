"""Обучение сегментации (тела / диски / очаги) на датасете из «Статистика → Скачать датасет».
  pip install torch onnx onnxruntime
  python tools/train_unet.py --dataset dataset.zip --epochs 120 --out models/
Схема – по ВКР (гл.2): U-Net, Dice+BCE, разбиение по пациентам 70/15/15 (поле split в manifest.json), аугментации без
отражения слева-направо (перед/зад анатомически разные). Экспортирует models/disc_seg.onnx (канал «диски»).
ВАЖНО: скрипт написан по спецификации и в среде разработки НЕ запускался (там нет torch/GPU) – при первом запуске
проверьте на 2–3 эпохах."""
import argparse, io, json, os, zipfile, random
import numpy as np, cv2
import torch, torch.nn as nn, torch.nn.functional as F

CLS = ["body", "disc", "lesion"]


class DS(torch.utils.data.Dataset):
    def __init__(self, z, items, aug):
        self.z, self.items, self.aug = z, items, aug

    def __len__(self):
        return len(self.items)

    def __getitem__(self, k):
        it = self.items[k]; base = it["image"][len("images/"):-4]
        img = cv2.imdecode(np.frombuffer(self.z.read(it["image"]), np.uint8), 0).astype(np.float32) / 255.0 * 1.2
        m = np.zeros((3,) + img.shape, np.float32)
        for c, name in enumerate(CLS):
            p = f"masks/{base}_{name}.png"
            if p in self.z.namelist():
                m[c] = cv2.imdecode(np.frombuffer(self.z.read(p), np.uint8), 0) > 127
        if self.aug:
            a = random.uniform(-7, 7); s = random.uniform(.92, 1.08); M = cv2.getRotationMatrix2D((img.shape[1] / 2, img.shape[0] / 2), a, s)
            img = cv2.warpAffine(img, M, img.shape[::-1], flags=cv2.INTER_LINEAR)
            m = np.stack([cv2.warpAffine(x, M, img.shape[::-1], flags=cv2.INTER_NEAREST) for x in m])
            img = img * random.uniform(.85, 1.15) + np.random.normal(0, .01, img.shape).astype(np.float32)
        return torch.from_numpy(img[None]), torch.from_numpy(m)


def block(i, o):
    return nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(True), nn.Conv2d(o, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(True))


class UNet(nn.Module):
    def __init__(self, n_out=3, w=24):
        super().__init__()
        ch = [w, w * 2, w * 4, w * 8]
        self.enc = nn.ModuleList([block(1, ch[0]), block(ch[0], ch[1]), block(ch[1], ch[2]), block(ch[2], ch[3])])
        self.up = nn.ModuleList([nn.ConvTranspose2d(ch[i], ch[i - 1], 2, 2) for i in (3, 2, 1)])
        self.dec = nn.ModuleList([block(ch[i - 1] * 2, ch[i - 1]) for i in (3, 2, 1)])
        self.out = nn.Conv2d(ch[0], n_out, 1)

    def forward(self, x):
        s = []
        for i, e in enumerate(self.enc):
            x = e(x if i == 0 else F.max_pool2d(x, 2)); s.append(x)
        x = s[-1]
        for u, d, sk in zip(self.up, self.dec, reversed(s[:-1])):
            x = d(torch.cat([u(x), sk], 1))
        return self.out(x)


def dice_loss(lo, y):
    p = torch.sigmoid(lo); i = (p * y).sum((2, 3)); u = p.sum((2, 3)) + y.sum((2, 3))
    return 1 - ((2 * i + 1) / (u + 1)).mean()


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--dataset", required=True); ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--bs", type=int, default=4); ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--out", default="models"); ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args(); random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    z = zipfile.ZipFile(a.dataset); man = json.loads(z.read("manifest.json"))["items"]
    sp = {k: [x for x in man if x["split"] == k] for k in ("train", "val", "test")}
    print({k: len(v) for k, v in sp.items()}); assert sp["train"], "нет обучающих срезов"
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tl = torch.utils.data.DataLoader(DS(z, sp["train"], True), batch_size=a.bs, shuffle=True)
    vl = torch.utils.data.DataLoader(DS(z, sp["val"] or sp["train"], False), batch_size=1)
    net = UNet().to(dev); opt = torch.optim.AdamW(net.parameters(), a.lr, weight_decay=1e-4)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.epochs); best, bad = 0, 0; os.makedirs(a.out, exist_ok=True)
    for ep in range(a.epochs):
        net.train()
        for x, y in tl:
            x, y = x.to(dev), y.to(dev); lo = net(x); loss = F.binary_cross_entropy_with_logits(lo, y) + dice_loss(lo, y)
            opt.zero_grad(); loss.backward(); opt.step()
        sch.step(); net.eval(); d = np.zeros(3); n = np.zeros(3)
        with torch.no_grad():
            for x, y in vl:
                p = (torch.sigmoid(net(x.to(dev))) > .5).float().cpu(); 
                for c in range(3):
                    if y[0, c].sum() > 0:
                        d[c] += (2 * (p[0, c] * y[0, c]).sum() / (p[0, c].sum() + y[0, c].sum() + 1e-6)).item(); n[c] += 1
        dsc = d / np.maximum(n, 1); score = dsc[:2].mean(); print(f"ep{ep:3d} loss {loss.item():.3f} val DSC body/disc/lesion {dsc.round(3)}")
        if score > best:
            best, bad = score, 0; torch.save(net.state_dict(), os.path.join(a.out, "unet.pt"))
        else:
            bad += 1
            if bad >= 25: break
    net.load_state_dict(torch.load(os.path.join(a.out, "unet.pt"))); net.eval().cpu()

    class DiscOnly(nn.Module):
        def __init__(s, n): super().__init__(); s.n = n
        def forward(s, x): return s.n(x)[:, 1:2]
    torch.onnx.export(DiscOnly(net), torch.zeros(1, 1, 512, 512), os.path.join(a.out, "disc_seg.onnx"), input_names=["x"], output_names=["y"],
                      dynamic_axes={"x": {2: "h", 3: "w"}, "y": {2: "h", 3: "w"}}, opset_version=17)
    print("готово: models/unet.pt, models/disc_seg.onnx; лучший DSC (тела+диски):", round(best, 3))


if __name__ == "__main__":
    main()
