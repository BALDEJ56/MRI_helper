import os, sys, json, sqlite3
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def data_dir(arg=None):
    return arg or os.environ.get("SPONDY_DATA") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def connect(d):
    con = sqlite3.connect(os.path.join(d, "spondy.db")); con.row_factory = sqlite3.Row
    return con
