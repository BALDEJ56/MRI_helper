"""Оценка качества алгоритма на накопленных данных:  python tools/evaluate.py [--data DIR]
1) сегментация: Dice/IoU алгоритма против разметки врача (тела, диски, очаги) на размеченных срезах;
2) классификация: срезы и исследования против заключений врача (Se, Sp, F1, κ), по аппаратам.
Целевые значения (ВКР): Se ≥ 0.85, Sp ≥ 0.80, DSC ≥ 0.75."""
import argparse, json, os
import numpy as np, cv2
from _common import data_dir, connect
from app.core import metrics as M

ap = argparse.ArgumentParser(); ap.add_argument("--data"); a = ap.parse_args()
d = data_dir(a.data); con = connect(d)
ann_dir = os.path.join(d, "annotations")
res = {}
for s in con.execute("SELECT DISTINCT series_id FROM annotations"):
    sid = s["series_id"]
    an = con.execute("SELECT result_json FROM analyses WHERE series_id=? AND mode='active' ORDER BY id DESC LIMIT 1", (sid,)).fetchone()
    meta = json.loads(con.execute("SELECT meta_json FROM series WHERE id=?", (sid,)).fetchone()["meta_json"])
    dev = meta.get("device_key", "?")
    if not an:
        continue
    r = json.loads(an["result_json"]); H, W = meta["rows"], meta["cols"]
    for row in con.execute("SELECT slice_index FROM annotations WHERE series_id=? GROUP BY slice_index", (sid,)):
        i = row["slice_index"]; sl = r["slices"][i]
        pred = {c: np.zeros((H, W), np.uint8) for c in ("body", "disc", "lesion")}
        for v in sl["vertebrae"]:
            if not v["extrapolated"]:
                cv2.fillPoly(pred["body"], [np.round(np.array(v["quad"])).astype(np.int32)], 1)
            for c in v["corners"].values():
                if c["positive"] and c["contour"]:
                    cv2.fillPoly(pred["lesion"], [np.round(np.array(c["contour"])).astype(np.int32)], 1)
        for q in sl.get("discs", []):
            cv2.fillPoly(pred["disc"], [np.round(np.array(q)).astype(np.int32)], 1)
        for c in pred:
            f = con.execute("SELECT file FROM annotations WHERE series_id=? AND slice_index=? AND cls=?", (sid, i, c)).fetchone()
            gt = cv2.imread(os.path.join(ann_dir, f["file"]), 0) > 127 if f else np.zeros((H, W), bool)
            res.setdefault((dev, c), []).append((M.dice(pred[c], gt), M.iou(pred[c], gt)))
print("== Сегментация (алгоритм vs разметка врача) ==")
for (dev, c), v in sorted(res.items()):
    v = np.array(v); print(f"{dev:32s} {c:7s} n={len(v):3d}  DSC={v[:,0].mean():.3f}  IoU={v[:,1].mean():.3f}")
print("\n== Классификация (алгоритм vs заключения врача) ==")
rows = con.execute("""SELECT a.positive ai, v.positive doc, v.slice_labels_json, a.result_json, st.device_key dev FROM analyses a
    JOIN studies st ON st.id=a.study_id JOIN verdicts v ON v.id=(SELECT MAX(id) FROM verdicts WHERE analysis_id=a.id) WHERE a.mode='active'""").fetchall()
st_t = [r["doc"] for r in rows if r["doc"] is not None]; st_p = [r["ai"] for r in rows if r["doc"] is not None]
print("исследования:", M.classification_metrics(st_t, st_p) if st_t else "нет данных")
yt, yp, ys = [], [], []
for r in rows:
    sl = json.loads(r["result_json"])["slices"]
    for k, v in json.loads(r["slice_labels_json"] or "{}").items():
        k = int(k)
        if k < len(sl) and sl[k]["informative"]:
            yt.append(v); yp.append(int(sl[k]["positive"]))
            ys.append(max([c["area_mm2"] for vv in sl[k]["vertebrae"] for c in vv["corners"].values()] + [0]))
print("срезы:", M.classification_metrics(yt, yp) if yt else "нет данных")
if yt:
    print("AUC по максимальной площади очага на срезе:", M.auc(yt, ys))
