"""Синтетический сагиттальный STIR-фантом позвоночника для проверки логики (НЕ клиническая валидация)."""
import numpy as np
from scipy import ndimage as ndi


def make_phantom(n_slices=9, lesion_slices=(3, 4, 5), lesion_level=3, lesion_corner="AS", central_vein=True,
                 seed=0, spacing=0.63, scale=1.0, size=512):
    rng = np.random.default_rng(seed)
    H = W = size
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    ys = [22, 74, 129, 187, 247, 307, 362]            # центры 7 дисков (px): Th11/12 … L5/S1
    vols = []
    mm = lambda v: v / spacing
    info = {}
    for s in range(n_slices):
        img = np.full((H, W), 0.04, np.float32)
        img[:, 150:330] = 0.09
        # канал (ликвор)
        img[:, 280:300] = 0.95
        # тела позвонков и диски
        for i, y in enumerate(ys):
            x0 = 245 - i * 2
            body_top = y + mm(3)
            nxt = ys[i + 1] if i + 1 < len(ys) else y + mm(38)
            body_bot = nxt - mm(3)
            img[int(body_top):int(body_bot), int(x0 - mm(11)):int(x0 + mm(11))] = 0.26
            ell = ((xx - x0) / mm(11)) ** 2 + ((yy - y) / mm(3.5)) ** 2 <= 1
            img[ell] = 0.7
        if central_vein:
            img[int(ys[2] + mm(14)):int(ys[2] + mm(20)), 238:246] = 0.7  # центральная вена (должна игнорироваться)
        if s in lesion_slices:
            i = lesion_level                       # тело между дисками lesion_level-1 и lesion_level ... (индекс тела = i-1)
            top = ys[i - 1] + mm(3); x0 = 245 - (i - 1) * 2
            if lesion_corner == "AS":
                L = mm(9)                      # треугольный очаг в переднем верхнем углу [2.docx 00:09:39]
                xl = x0 - mm(11)
                tri = ((xx - xl) + (yy - top)) <= L
                tri &= (xx >= xl) & (yy >= top)
                img[tri] = 0.50
        img = img + rng.normal(0, 0.025, img.shape).astype(np.float32)
        img = np.clip(img, 0, None)
        vols.append(ndi.gaussian_filter(img, 0.6) * 600)
    return np.stack(vols).astype(np.float32), (spacing, spacing)
