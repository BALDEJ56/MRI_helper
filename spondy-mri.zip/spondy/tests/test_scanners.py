import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import numpy as np
from app.core.dicom_io import load_series_from_paths
from app.core.config import AnalysisParams
from app.core.pipeline import analyze_series
from tests.phantom import make_phantom
from tests.make_dicom import write_series


def _load(d):
    return [s for s in load_series_from_paths([d]) if s.plane == "sagittal"][0]


def test_orientation_variants_give_same_canonical_volume():
    vol, sp = make_phantom(lesion_slices=(3, 4, 5))
    vol = np.round(vol)
    base = _load_dir(vol, sp, "Philips")
    # перенос осей: столбцы растут вперёд (зеркало), строки растут краниально (флип по вертикали)
    mir = _load_dir(vol, sp, "Philips", iop=[0, -1, 0, 0, 0, -1], mirror_lr=True)
    ud = _load_dir(vol, sp, "Philips", iop=[0, 1, 0, 0, 0, 1], flip_ud=True)
    assert np.allclose(base.volume, mir.volume) and np.allclose(base.volume, ud.volume)
    assert mir.flipped_lr and ud.flipped_ud and not base.flipped_lr


def _load_dir(vol, sp, vendor, **kw):
    d = tempfile.mkdtemp(); write_series(d, vol, sp, vendor, **kw); return _load(d)


def test_two_vendors_same_conclusion_and_scale_invariance():
    vol, sp = make_phantom(lesion_slices=(3, 4, 5))
    vol = vol / vol.max() * 800
    ge = _load_dir(vol, sp, "GE", scale=1.0)
    ph = _load_dir(vol, sp, "Philips", scale=3.7)      # иная абсолютная шкала яркости
    assert ge.device_key != ph.device_key and ge.weighting == ph.weighting == "STIR"
    r1 = analyze_series(ge.volume, ge.spacing_mm, AnalysisParams()); r2 = analyze_series(ph.volume, ph.spacing_mm, AnalysisParams())
    f = lambda r: [(x["level"], x["corner"], tuple(x["slices"])) for x in r["study"]["findings"]]
    assert r1["study"]["positive"] and f(r1) == f(r2)
