import sys, os, io, json, tempfile, zipfile
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import numpy as np
import pytest
from app import create_app
from tests.phantom import make_phantom
from tests.make_dicom import write_series

H = {"X-Requested-With": "fetch"}


def _files(d):
    return [(open(os.path.join(d, f), "rb"), f) for f in sorted(os.listdir(d))]


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setenv("SPONDY_ADMIN_PASSWORD", "testpass123")
    app = create_app(tempfile.mkdtemp()); c = app.test_client()
    assert c.post("/api/login", json={"username": "admin", "password": "testpass123"}, headers=H).status_code == 200
    c.app = app
    return c


def _add_case(c, vendor, lesion, scale=1.0):
    vol, sp = make_phantom(lesion_slices=(3, 4, 5) if lesion else ())
    vol = vol / vol.max() * 800
    d = tempfile.mkdtemp(); write_series(d, vol, sp, vendor, scale=scale)
    pid = c.post("/api/patients", json={}, headers=H).get_json()["id"]
    r = c.post(f"/api/patients/{pid}/upload", data={"files": _files(d)}, content_type="multipart/form-data", headers=H)
    assert r.status_code == 200, r.get_json()
    return pid, r.get_json()["study_ids"][0]


def test_auth_required_and_csrf(client):
    other = client.application.test_client()
    assert other.get("/api/patients").status_code == 401
    assert client.post("/api/patients", json={}).status_code == 403          # нет X-Requested-With


def test_full_cycle_two_vendors(client):
    p1, s1 = _add_case(client, "GE", True); p2, s2 = _add_case(client, "Philips", False, scale=3.7)
    a1 = client.post(f"/api/studies/{s1}/analyze", json={}, headers=H).get_json()
    a2 = client.post(f"/api/studies/{s2}/analyze", json={}, headers=H).get_json()
    assert a1["result"]["study"]["positive"] and not a2["result"]["study"]["positive"]
    assert "активного воспаления" in a1["result"]["study"]["conclusion"]
    # врач соглашается с алгоритмом по срезам
    aid = a1["analysis_ids"]["active"]; labels = {str(i): int(i in (3, 4, 5)) for i in range(9)}
    assert client.post(f"/api/analyses/{aid}/verdict", json={"positive": True, "slice_labels": labels}, headers=H).status_code == 200
    st = client.get("/api/stats").get_json()
    assert st["patients"] == 2 and len(st["by_device"]) == 2
    assert st["agreement_study"]["tp"] == 1
    # реестр
    pl = client.get("/api/patients").get_json()
    assert {p["ai_positive"] for p in pl} == {0, 1}
    # ДАННЫЕ ОБЕЗЛИЧЕНЫ: ни имени, ни ID из DICOM нет в БД
    dump = open(client.application.config["DB_PATH"], "rb").read()
    assert b"Phantom" not in dump and b"PH-1" not in dump


def test_annotation_roundtrip_and_dataset_export(client):
    pid, sid = _add_case(client, "GE", True)
    a = client.post(f"/api/studies/{sid}/analyze", json={}, headers=H).get_json()
    ser = a["result"]["series"]["id"]; aid = a["analysis_ids"]["active"]
    pf = client.post(f"/api/series/{ser}/annotations/4/prefill", json={"analysis_id": aid}, headers=H).get_json()["masks"]
    assert client.put(f"/api/series/{ser}/annotations/4", json={"masks": pf}, headers=H).status_code == 200
    assert set(client.get(f"/api/series/{ser}/annotations").get_json()["4"]) >= {"body", "disc", "lesion"}
    z = zipfile.ZipFile(io.BytesIO(client.get("/api/export/dataset.zip").data))
    man = json.loads(z.read("manifest.json"))["items"]
    assert len(man) == 1 and man[0]["split"] in ("train", "val", "test")
    assert any(n.startswith("masks/") and n.endswith("_lesion.png") for n in z.namelist())


def test_sij_region_not_analyzed_but_registered(client):
    vol, sp = make_phantom(); d = tempfile.mkdtemp(); write_series(d, vol, sp, "GE")
    pid = client.post("/api/patients", json={}, headers=H).get_json()["id"]
    sid = client.post(f"/api/patients/{pid}/upload", data={"files": _files(d), "region": "sij"}, content_type="multipart/form-data", headers=H).get_json()["study_ids"][0]
    r = client.post(f"/api/studies/{sid}/analyze", json={}, headers=H)
    assert r.status_code == 501 and "КПС" in r.get_json()["error"]


def test_non_dicom_rejected(client):
    pid = client.post("/api/patients", json={}, headers=H).get_json()["id"]
    r = client.post(f"/api/patients/{pid}/upload", data={"files": (io.BytesIO(b"not dicom"), "x.dcm")}, content_type="multipart/form-data", headers=H)
    assert r.status_code == 400


def test_reader_agreement(client):
    pid, sid = _add_case(client, "GE", True)
    aid = client.post(f"/api/studies/{sid}/analyze", json={}, headers=H).get_json()["analysis_ids"]["active"]
    client.post("/api/users", json={"username": "reader2", "password": "reader2pass", "role": "doctor"}, headers=H)
    client.post(f"/api/analyses/{aid}/verdict", json={"positive": True}, headers=H)
    c2 = client.application.test_client()
    c2.post("/api/login", json={"username": "reader2", "password": "reader2pass"}, headers=H)
    c2.post(f"/api/analyses/{aid}/verdict", json={"positive": True}, headers=H)
    ra = client.get("/api/stats").get_json()["reader_agreement"]
    assert ra["n"] == 1 and ra["tp"] == 1
