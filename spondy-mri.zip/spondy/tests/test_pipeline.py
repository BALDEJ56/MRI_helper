import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import numpy as np
from app.core.config import AnalysisParams
from app.core.pipeline import analyze_series
from tests.phantom import make_phantom


def test_phantom_lesion_detected_and_vein_ignored():
    vol, sp = make_phantom()
    r = analyze_series(vol, sp, AnalysisParams())
    st = r["study"]
    assert st["n_informative"] >= 7
    assert st["positive"]
    f = [(x["level"], x["corner"]) for x in st["findings"]]
    assert ("L1", "AS") in f or ("L2", "AS") in f or ("L3", "AS") in f
    assert all(c == "AS" for _, c in f)            # центральная вена не даёт ложных срабатываний
    assert set(r["study"]["positive_slices"]) <= {3, 4, 5}


def test_phantom_negative():
    vol, sp = make_phantom(lesion_slices=())
    r = analyze_series(vol, sp, AnalysisParams())
    assert not r["study"]["positive"]


def test_consecutive_rule():
    vol, sp = make_phantom(lesion_slices=(4,))
    assert analyze_series(vol, sp, AnalysisParams(min_consecutive_slices=1))["study"]["positive"]
    assert not analyze_series(vol, sp, AnalysisParams(min_consecutive_slices=2))["study"]["positive"]


def test_labels_seven_levels():
    vol, sp = make_phantom(lesion_slices=())
    r = analyze_series(vol, sp, AnalysisParams())
    s = next(s for s in r["slices"] if s["informative"])
    assert [v["label"] for v in s["vertebrae"]] == ["Th12", "L1", "L2", "L3", "L4", "L5", "S1"]
