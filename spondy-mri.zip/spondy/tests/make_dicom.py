"""Запись синтетических сагиттальных DICOM-серий (для тестов двух аппаратов; НЕ реальные снимки)."""
import os, datetime
import numpy as np
import pydicom
from pydicom.dataset import Dataset, FileMetaDataset
from pydicom.uid import ExplicitVRLittleEndian, generate_uid, MRImageStorage

VENDORS = {
    # типичные ориентации: GE – слегка наклонённые оси; Philips – ровные
    "GE": dict(manufacturer="GE MEDICAL SYSTEMS", model="SIGNA Explorer", iop=[0, 1, 0, 0, 0, -1], field=1.5),
    "Philips": dict(manufacturer="Philips Medical Systems", model="Multiva", iop=[0, 1, 0, 0, 0, -1], field=1.5),
}


def write_series(outdir, vol, spacing, vendor="Philips", description="Sag STIR", iop=None, mirror_lr=False, flip_ud=False,
                 study_uid=None, series_uid=None, scale=1.0, weighting="STIR"):
    os.makedirs(outdir, exist_ok=True)
    v = VENDORS[vendor]; iop = iop or v["iop"]
    study_uid = study_uid or generate_uid(); series_uid = series_uid or generate_uid()
    for i, sl in enumerate(vol):
        a = sl[:, ::-1] if mirror_lr else sl
        a = a[::-1, :] if flip_ud else a
        a = np.clip(a * scale, 0, 4095).astype(np.uint16)
        meta = FileMetaDataset(); meta.MediaStorageSOPClassUID = MRImageStorage; meta.MediaStorageSOPInstanceUID = generate_uid()
        meta.TransferSyntaxUID = ExplicitVRLittleEndian
        ds = Dataset(); ds.file_meta = meta; ds.is_little_endian = True; ds.is_implicit_VR = False
        ds.SOPClassUID = MRImageStorage; ds.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
        ds.Modality = "MR"; ds.Manufacturer = v["manufacturer"]; ds.ManufacturerModelName = v["model"]; ds.MagneticFieldStrength = v["field"]
        ds.PatientName = "Test^Phantom"; ds.PatientID = "PH-1"; ds.PatientSex = "F"; ds.StudyDate = "20260301"
        ds.StudyInstanceUID = study_uid; ds.SeriesInstanceUID = series_uid; ds.SeriesDescription = description; ds.BodyPartExamined = "LSPINE"
        ds.InstanceNumber = i + 1; ds.ImageOrientationPatient = [float(x) for x in iop]
        ds.ImagePositionPatient = [float(i * 4.0), 0.0, 0.0]; ds.SliceThickness = 3.6; ds.PixelSpacing = [spacing[0], spacing[1]]
        ds.ScanningSequence = "IR" if weighting == "STIR" else "SE"; ds.RepetitionTime = 5000 if weighting == "STIR" else 500
        ds.EchoTime = 60 if weighting == "STIR" else 12; 
        if weighting == "STIR": ds.InversionTime = 150
        ds.Rows, ds.Columns = a.shape; ds.SamplesPerPixel = 1; ds.PhotometricInterpretation = "MONOCHROME2"
        ds.BitsAllocated = 16; ds.BitsStored = 12; ds.HighBit = 11; ds.PixelRepresentation = 0; ds.PixelData = a.tobytes()
        ds.save_as(os.path.join(outdir, f"IM{i + 1:04d}"), enforce_file_format=True)
    return study_uid, series_uid
