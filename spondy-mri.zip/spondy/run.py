"""Запуск: python run.py [--host 0.0.0.0] [--port 8000]
Первый запуск создаёт пользователя admin (пароль печатается в консоль или берётся из SPONDY_ADMIN_PASSWORD)."""
import argparse
from app import create_app

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1"); ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    create_app().run(host=a.host, port=a.port, threaded=True)
