Сюда кладутся обученные модели в формате ONNX (нужен `pip install onnxruntime`):
- `disc_seg.onnx`  – сегментация дисков (tools/train_unet.py)
- `corner_clf.onnx` – классификатор угла 32×32 (tools/train_corner_clf.py)
Без файлов работает классический метод.
